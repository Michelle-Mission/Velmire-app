# Code of Conduct

## Our standard

Contributors are expected to be respectful, constructive, and focused on the project.

Unacceptable behavior includes harassment, personal attacks, threats, deliberate disruption, and publishing someone else's private information.

## Enforcement

Project maintainers may remove comments, issues, pull requests, or participation that violates this code of conduct.

If you need to report a conduct issue, contact the repository maintainer privately.
