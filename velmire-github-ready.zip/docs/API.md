# API Notes

Velmire currently uses MangaDex public HTTP endpoints directly.

## Endpoints observed in the current source

### Manga list

```http
GET https://api.mangadex.org/manga
```

Used for feed/search-style manga retrieval.

### Manga detail

```http
GET https://api.mangadex.org/manga/{mangaId}
```

Used by `DetailActivity`.

### Manga aggregate

```http
GET https://api.mangadex.org/manga/{mangaId}/aggregate
```

Used to obtain chapter information grouped by volume/chapter.

### Tags

```http
GET https://api.mangadex.org/manga/tag
```

Used by `MangaTags` to synchronize genre/tag choices.

### Chapter reader server

```http
GET https://api.mangadex.org/at-home/server/{chapterId}
```

Used by `ReadActivity` to obtain chapter image information.

### Covers

The current source constructs cover URLs using MangaDex's upload infrastructure.

## Important development notes

MangaDex is an external service. API behavior, limits, response fields, policies, and content availability can change.

When modifying API code:

- Do not assume fields are always present.
- Handle HTTP `429` and server errors.
- Avoid request loops.
- Keep pagination bounded.
- Do not hammer the API while typing in search.
- Cache data where it is safe and useful.
- Re-check current MangaDex documentation before relying on undocumented behavior.

## API abstraction

A future refactor should consider a dedicated client such as:

```text
MangaDexClient
 ├── searchManga(...)
 ├── getManga(...)
 ├── getTags(...)
 ├── getChapters(...)
 └── getChapterPages(...)
```

UI components should ideally depend on this abstraction rather than constructing endpoint strings themselves.
