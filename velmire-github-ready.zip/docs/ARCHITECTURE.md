# Velmire Architecture

This document describes the architecture of the current source snapshot.

## High-level flow

```text
MainActivity
   │
   ├── FeedFragment ──────┐
   ├── LibraryFragment    │
   ├── HistoryFragment    │
   ├── SearchFragment     │
   └── MoreFragment       │
                           ▼
                    MangaDex HTTP API
                           │
                           ▼
                     DetailActivity
                           │
                           ▼
                      ReadActivity
                           │
                           ├── chapter metadata
                           └── reader images
```

## Main components

### `MainActivity`

Owns the main navigation and coordinates the top-level screens.

### `FeedFragment`

Loads and filters manga lists. It currently supports sorting, status filtering, genre filtering, pagination, and language-aware filtering.

### `SearchFragment`

Provides local search history and delayed remote suggestions. A submitted query is handed back to the main browsing flow.

### `DetailActivity`

Loads manga details and chapters. It handles chapter ordering, language filtering, favorite state, and resume-from-history behavior.

### `ReadActivity`

Loads chapter pages from MangaDex's at-home server, displays them vertically, stores reading progress, and can move between chapters.

### `Net`

Shared networking and image-loading helper. It contains:

- HTTP GET handling
- retry behavior for selected HTTP errors
- in-memory image cache
- disk image cache
- asynchronous image loading
- image-size handling

### `Library`

Stores the user's local manga library/favorites in `SharedPreferences`.

### `History`

Stores recently read manga/chapter/page information locally.

### `SearchHistory`

Stores search history locally.

### `Settings`

Stores chapter language and Data Saver preferences.

### `MangaTags`

Loads MangaDex tag/genre metadata.

## Persistence

The current implementation uses the same `velmire_prefs` `SharedPreferences` file for several local features.

This is simple and suitable for a prototype, but a future larger version may benefit from Room or another structured local database.

## Network architecture

The application talks directly to MangaDex from Android code.

Current endpoint families include:

```text
GET https://api.mangadex.org/manga
GET https://api.mangadex.org/manga/{id}
GET https://api.mangadex.org/manga/{id}/aggregate
GET https://api.mangadex.org/manga/tag
GET https://api.mangadex.org/at-home/server/{chapter-id}
```

Cover images are built from MangaDex's upload host.

Avoid spreading raw endpoint strings throughout new classes. If the API surface grows, introduce a central API configuration/client layer.

## Recommended future refactor

A larger version of Velmire would benefit from:

```text
UI
 │
 ▼
ViewModel / state holder
 │
 ▼
Repository
 ├── MangaDex API client
 └── Local database/cache
```

This would make UI code easier to test and reduce direct networking from Activities/Fragments.
