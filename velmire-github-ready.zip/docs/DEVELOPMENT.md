# Development Guide

## Environment

Recommended baseline:

- Android Studio
- JDK 17
- Android SDK 34
- Android SDK Build Tools installed by Android Studio
- Gradle compatible with AGP 8.12.x

## First build

The current source snapshot does not include a Gradle Wrapper and has two missing manifest-referenced classes.

Before expecting a clean build:

1. Restore or recreate `SketchApplication`.
2. Restore or recreate `DebugActivity`, or remove the obsolete manifest reference.
3. Add the Gradle Wrapper.
4. Open the project in Android Studio.
5. Sync Gradle.
6. Build the `app` module.

## Debugging network problems

The app depends heavily on remote MangaDex endpoints. When a screen is empty:

1. Check internet permission and device connectivity.
2. Check Logcat for the HTTP status/error.
3. Test whether the relevant MangaDex endpoint is currently responding.
4. Check whether the requested manga/chapter has the selected language.
5. Check whether the API response schema has changed.

Do not solve an API error by simply increasing request frequency.

## Release preparation

Before publishing an APK/AAB:

- Set a real application version.
- Configure release signing outside the repository.
- Confirm `minifyEnabled` and ProGuard/R8 behavior.
- Remove debug-only components.
- Review network security configuration.
- Review permissions.
- Verify privacy/data handling.
- Verify MangaDex attribution and usage requirements.
- Add a project license.
- Test on multiple Android versions.
- Test offline/error states.

## Suggested testing matrix

At minimum test:

- Fresh install
- Existing user data after update
- Empty search
- No search results
- Manga with missing cover
- Manga with multiple languages
- Chapter with missing metadata
- Slow network
- HTTP 429
- Network offline
- Reader rotation/configuration changes
- Resume reading
- Clear history
- Add/remove library item
- Clear cache
