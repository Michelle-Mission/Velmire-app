package com.velmire;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class Net {

    public static final String USER_AGENT = "Velmire/1.0";
    public static String CHAPTER_LANG = Settings.LANG_ALL;
    private static final int MAX_TEXTURE = 8192;
    private static final long MAX_DISK_BYTES = 150L * 1024 * 1024;
    private static final int TRIM_EVERY_N_DOWNLOADS = 20;

    public static class HttpError extends IOException {
        public final int code;

        public HttpError(int code) {
            super("HTTP " + code);
            this.code = code;
        }
    }

    public interface Callback {
        void onLoaded(Bitmap bitmap);
        void onFailed(String reason);
    }

    private static final Handler MAIN =
            new Handler(Looper.getMainLooper());

    private static final ExecutorService POOL =
            Executors.newFixedThreadPool(4);

    private static final Map<ImageView, String> TAGS =
            Collections.synchronizedMap(
                    new WeakHashMap<ImageView, String>()
            );

    private static final AtomicInteger downloadCounter =
            new AtomicInteger();

    private static LruCache<String, Bitmap> memCache;
    private static File diskDir;

    // ---------------------------------------------------------
    // Init
    // ---------------------------------------------------------

    private static synchronized void init(Context ctx) {
        if (memCache != null && diskDir != null) {
            return;
        }

        Context appContext = ctx.getApplicationContext();

        // Memory cache sekitar 1/8 memory aplikasi
        final int maxMemoryKb =
                (int) (Runtime.getRuntime().maxMemory() / 1024);

        final int cacheSizeKb = Math.max(
                4 * 1024,
                maxMemoryKb / 8
        );

        memCache = new LruCache<String, Bitmap>(cacheSizeKb) {

            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                if (bitmap == null) return 0;

                if (android.os.Build.VERSION.SDK_INT >= 19) {
                    return bitmap.getAllocationByteCount() / 1024;
                }

                return bitmap.getByteCount() / 1024;
            }
        };

        diskDir = new File(
                appContext.getCacheDir(),
                "img"
        );

        if (!diskDir.exists()) {
            diskDir.mkdirs();
        }

        POOL.execute(new Runnable() {
            @Override
            public void run() {
                trimDisk();
            }
        });
    }

    // ---------------------------------------------------------
    // DP
    // ---------------------------------------------------------

    public static int dp(Context c, int v) {
        return (int) (
                v * c.getResources()
                        .getDisplayMetrics()
                        .density + 0.5f
        );
    }

    // ---------------------------------------------------------
    // HTTP JSON
    // ---------------------------------------------------------

    public static String get(String apiUrl) throws IOException {
        int attempt = 0;

        while (true) {
            try {
                return doGet(apiUrl);

            } catch (HttpError e) {

                boolean retryable =
                        e.code == 429 || e.code >= 500;

                if (!retryable || attempt >= 2) {
                    throw e;
                }
            }

            attempt++;

            try {
                Thread.sleep(1200L * attempt);

            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new IOException("Dibatalkan");
            }
        }
    }

    private static String doGet(String apiUrl) throws IOException {
        HttpURLConnection conn = null;

        try {
            conn = (HttpURLConnection)
                    new URL(apiUrl).openConnection();

            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);

            conn.setRequestProperty(
                    "User-Agent",
                    USER_AGENT
            );

            conn.setRequestProperty(
                    "Accept",
                    "application/json"
            );

            int code = conn.getResponseCode();

            if (code != HttpURLConnection.HTTP_OK) {
                throw new HttpError(code);
            }

            StringBuilder sb = new StringBuilder();

            try (BufferedReader reader =
                         new BufferedReader(
                                 new InputStreamReader(
                                         conn.getInputStream(),
                                         "UTF-8"
                                 )
                         )) {

                String line;

                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            return sb.toString();

        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    // ---------------------------------------------------------
    // Error
    // ---------------------------------------------------------

    public static String describe(Exception e) {

        if (e instanceof HttpError) {
            int code = ((HttpError) e).code;

            if (code == 429) {
                return "Terlalu banyak request, coba lagi sebentar";
            }

            if (code == 404) {
                return "Data tidak ditemukan (404)";
            }

            if (code == 403) {
                return "Akses ditolak (403)";
            }

            if (code >= 500) {
                return "Server error (" + code + ")";
            }

            return "HTTP error (" + code + ")";
        }

        if (e instanceof UnknownHostException) {
            return "Tidak ada koneksi internet";
        }

        if (e instanceof SocketTimeoutException) {
            return "Koneksi timeout";
        }

        String message = e.getMessage();

        if (message == null || message.isEmpty()) {
            return "Terjadi kesalahan";
        }

        return message;
    }

    // ---------------------------------------------------------
    // Image Loader
    // ---------------------------------------------------------

    public static void loadImage(
            Context ctx,
            final String url,
            final ImageView view,
            final int reqWidth,
            final boolean lowMemory,
            final Callback cb
    ) {

        if (view == null) {
            return;
        }

        init(ctx);

        // URL kosong
        if (url == null || url.trim().isEmpty()) {

            TAGS.remove(view);

            view.setImageDrawable(null);

            if (cb != null) {
                cb.onFailed("URL gambar kosong");
            }

            return;
        }

        final String key =
                (lowMemory ? "L|" : "H|") + url;

        // Tandai ImageView sedang digunakan untuk URL ini
        TAGS.put(view, key);

        // Cek memory cache
        Bitmap cached = memCache.get(key);

        if (cached != null) {

            view.setImageBitmap(cached);

            if (cb != null) {
                cb.onLoaded(cached);
            }

            return;
        }

        // Reset gambar lama sebelum async load
        view.setImageDrawable(null);

        POOL.execute(new Runnable() {

            @Override
            public void run() {

                // Pastikan ImageView masih menunjuk item yang sama
                if (!key.equals(TAGS.get(view))) {
                    return;
                }

                try {

                    File file = new File(
                            diskDir,
                            md5(url)
                    );

                    // Download jika belum ada
                    if (!file.exists() || file.length() == 0) {

                        download(url, file);

                        int count =
                                downloadCounter.incrementAndGet();

                        if (count % TRIM_EVERY_N_DOWNLOADS == 0) {
                            trimDisk();
                        }

                    } else {

                        // Update waktu akses cache
                        file.setLastModified(
                                System.currentTimeMillis()
                        );
                    }

                    // Decode gambar
                    final Bitmap bmp =
                            decode(
                                    file,
                                    reqWidth,
                                    lowMemory
                            );

                    if (bmp == null) {

                        file.delete();

                        throw new IOException(
                                "Gambar gagal didecode"
                        );
                    }

                    // Simpan ke memory cache
                    memCache.put(key, bmp);

                    // Update ImageView di main thread
                    MAIN.post(new Runnable() {

                        @Override
                        public void run() {

                            // ImageView mungkin sudah direcycle
                            if (!key.equals(TAGS.get(view))) {
                                return;
                            }

                            view.setImageBitmap(bmp);

                            if (cb != null) {
                                cb.onLoaded(bmp);
                            }
                        }
                    });

                } catch (final Exception e) {

                    MAIN.post(new Runnable() {

                        @Override
                        public void run() {

                            if (!key.equals(TAGS.get(view))) {
                                return;
                            }

                            if (cb != null) {
                                cb.onFailed(
                                        describe(e)
                                );
                            }
                        }
                    });
                }
            }
        });
    }

    // ---------------------------------------------------------
    // Download
    // ---------------------------------------------------------

    private static void download(
            String imageUrl,
            File dest
    ) throws IOException {

        HttpURLConnection conn = null;
        InputStream in = null;
        FileOutputStream out = null;

        File tmp = new File(
                dest.getPath()
                        + "."
                        + Thread.currentThread().getId()
                        + ".tmp"
        );

        try {

            conn = (HttpURLConnection)
                    new URL(imageUrl).openConnection();

            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);

            conn.setRequestProperty(
                    "User-Agent",
                    USER_AGENT
            );

            int code = conn.getResponseCode();

            if (code != HttpURLConnection.HTTP_OK) {
                throw new HttpError(code);
            }

            in = conn.getInputStream();

            out = new FileOutputStream(tmp);

            byte[] buffer = new byte[16 * 1024];

            int n;

            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
            }

            out.flush();

            out.close();
            out = null;

            // Hapus file lama jika ada
            if (dest.exists() && !dest.delete()) {
                throw new IOException(
                        "Gagal mengganti cache lama"
                );
            }

            if (!tmp.renameTo(dest)) {
                throw new IOException(
                        "Gagal simpan cache"
                );
            }

        } finally {

            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ignored) {
            }

            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException ignored) {
            }

            if (conn != null) {
                conn.disconnect();
            }

            if (tmp.exists()) {
                tmp.delete();
            }
        }
    }

    // ---------------------------------------------------------
    // Decode Bitmap
    // ---------------------------------------------------------

    private static Bitmap decode(
            File file,
            int reqWidth,
            boolean lowMemory
    ) {

        try {

            BitmapFactory.Options options =
                    new BitmapFactory.Options();

            options.inJustDecodeBounds = true;

            BitmapFactory.decodeFile(
                    file.getPath(),
                    options
            );

            if (options.outWidth <= 0
                    || options.outHeight <= 0) {

                return null;
            }

            int sample = 1;

            while (
                    options.outWidth / sample > MAX_TEXTURE
                            || options.outHeight / sample > MAX_TEXTURE
                            || (
                            reqWidth > 0
                                    && options.outWidth / sample
                                    > reqWidth * 2
                    )
            ) {

                sample *= 2;
            }

            options.inJustDecodeBounds = false;
            options.inSampleSize = sample;

            options.inPreferredConfig =
                    lowMemory
                            ? Bitmap.Config.RGB_565
                            : Bitmap.Config.ARGB_8888;

            return BitmapFactory.decodeFile(
                    file.getPath(),
                    options
            );

        } catch (OutOfMemoryError oom) {

            if (memCache != null) {
                memCache.evictAll();
            }

            return null;
        }
    }

    // ---------------------------------------------------------
    // Disk Cache
    // ---------------------------------------------------------

    private static synchronized void trimDisk() {

        if (diskDir == null) {
            return;
        }

        File[] files = diskDir.listFiles();

        if (files == null) {
            return;
        }

        long total = 0;

        for (File file : files) {

            if (file.isFile()) {
                total += file.length();
            }
        }

        if (total <= MAX_DISK_BYTES) {
            return;
        }

        Arrays.sort(
                files,
                new Comparator<File>() {

                    @Override
                    public int compare(
                            File a,
                            File b
                    ) {

                        return Long.compare(
                                a.lastModified(),
                                b.lastModified()
                        );
                    }
                }
        );

        long target =
                (long) (MAX_DISK_BYTES * 0.7);

        for (File file : files) {

            if (total <= target) {
                break;
            }

            if (!file.isFile()) {
                continue;
            }

            long length = file.length();

            if (file.delete()) {
                total -= length;
            }
        }
    }

    // ---------------------------------------------------------
    // MD5
    // ---------------------------------------------------------

    private static String md5(String s) {

        try {

            MessageDigest md =
                    MessageDigest.getInstance("MD5");

            byte[] data =
                    md.digest(
                            s.getBytes("UTF-8")
                    );

            StringBuilder sb =
                    new StringBuilder();

            for (byte b : data) {

                sb.append(
                        String.format(
                                "%02x",
                                b & 0xff
                        )
                );
            }

            return sb.toString();

        } catch (Exception e) {

            return String.valueOf(
                    s.hashCode()
            );
        }
    }

    // ---------------------------------------------------------
    // Clear Cache
    // ---------------------------------------------------------

    public static void clearCache(
            Context ctx
    ) {

        init(ctx);

        if (memCache != null) {
            memCache.evictAll();
        }

        POOL.execute(new Runnable() {

            @Override
            public void run() {

                if (diskDir == null) {
                    return;
                }

                File[] files =
                        diskDir.listFiles();

                if (files == null) {
                    return;
                }

                for (File file : files) {

                    if (file.isFile()) {
                        file.delete();
                    }
                }
            }
        });
    }
}