package com.velmire;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final int ID_HOME = 1;
    private static final int ID_LIBRARY = 2;
    private static final int ID_HISTORY = 3;
    private static final int ID_BROWSE = 4;
    private static final int ID_MORE = 5;

    private static final int[] IDS = {
            ID_HOME,
            ID_LIBRARY,
            ID_HISTORY,
            ID_BROWSE,
            ID_MORE
    };

    private static final String[] TAGS = {
            "home",
            "library",
            "history",
            "browse",
            "more"
    };

    private static final String TAG_SEARCH = "search";

    private BottomNavigationView bottomNav;
    private View searchContainer;
    private boolean searchOpen = false;
    private int currentId = ID_HOME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Muat bahasa chapter yang tersimpan sebelum dipakai FeedFragment/DetailActivity/dll.
        Net.CHAPTER_LANG = Settings.getChapterLang(this);

        setContentView(R.layout.main);

        bottomNav = findViewById(R.id.bottom_nav);
        searchContainer = findViewById(R.id.search_container);

        buildNav();

        FragmentManager fm = getSupportFragmentManager();

        if (savedInstanceState == null) {

            Fragment home = FeedFragment.newInstance(false);
            Fragment library = new LibraryFragment();
            Fragment history = new HistoryFragment();
            Fragment browse = FeedFragment.newInstance(true);
            Fragment more = new MoreFragment();

            fm.beginTransaction()
                    .add(R.id.fragment_container, home, TAGS[0])
                    .add(R.id.fragment_container, library, TAGS[1])
                    .add(R.id.fragment_container, history, TAGS[2])
                    .add(R.id.fragment_container, browse, TAGS[3])
                    .add(R.id.fragment_container, more, TAGS[4])
                    .hide(library)
                    .hide(history)
                    .hide(browse)
                    .hide(more)
                    .commitNow();

        } else {

            currentId = savedInstanceState.getInt("tab", ID_HOME);

            showTab(currentId);

            // Buang layar pencarian sisa dari instance sebelumnya
            Fragment stale = fm.findFragmentByTag(TAG_SEARCH);

            if (stale != null) {
                fm.beginTransaction()
                        .remove(stale)
                        .commit();
            }
        }

        bottomNav.setSelectedItemId(currentId);
    }

    private void buildNav() {

        Menu menu = bottomNav.getMenu();

        menu.add(Menu.NONE, ID_HOME, Menu.NONE, "Beranda")
                .setIcon(Icons.get(this, Icons.HOME));

        menu.add(Menu.NONE, ID_LIBRARY, Menu.NONE, "Pustaka")
                .setIcon(Icons.get(this, Icons.LIBRARY));

        menu.add(Menu.NONE, ID_HISTORY, Menu.NONE, "Riwayat")
                .setIcon(Icons.get(this, Icons.HISTORY));

        menu.add(Menu.NONE, ID_BROWSE, Menu.NONE, "Jelajahi")
                .setIcon(Icons.get(this, Icons.EXPLORE));

        menu.add(Menu.NONE, ID_MORE, Menu.NONE, "Lainnya")
                .setIcon(Icons.get(this, Icons.MORE));

        ColorStateList tint = new ColorStateList(
                new int[][]{
                        new int[]{android.R.attr.state_checked},
                        new int[]{}
                },
                new int[]{
                        0xFFD6E3FF,
                        0xFFA6A6AB
                }
        );

        bottomNav.setItemIconTintList(tint);
        bottomNav.setItemTextColor(tint);
        bottomNav.setBackgroundColor(0xFF1C1C1E);
        bottomNav.setLabelVisibilityMode(1);

        bottomNav.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem item) {
                        showTab(item.getItemId());
                        return true;
                    }
                }
        );
    }

    private void showTab(int id) {

        currentId = id;

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        for (int i = 0; i < IDS.length; i++) {

            Fragment f = fm.findFragmentByTag(TAGS[i]);

            if (f == null) {
                continue;
            }

            if (IDS[i] == id) {
                ft.show(f);
            } else {
                ft.hide(f);
            }
        }

        ft.commit();
    }

    // ---------- Pencarian ----------

    // Dipanggil tombol search di setiap tab.
    // Layar pencarian menutupi seluruh layar termasuk nav bawah.
    public void openSearch(String prefill) {

        if (searchOpen) {
            return;
        }

        searchOpen = true;

        searchContainer.setVisibility(View.VISIBLE);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(
                        R.id.search_container,
                        SearchFragment.newInstance(prefill),
                        TAG_SEARCH
                )
                .commit();
    }

    public void closeSearch() {

        if (!searchOpen) {
            return;
        }

        searchOpen = false;

        InputMethodManager imm =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        if (imm != null) {
            imm.hideSoftInputFromWindow(
                    searchContainer.getWindowToken(),
                    0
            );
        }

        FragmentManager fm = getSupportFragmentManager();

        Fragment f = fm.findFragmentByTag(TAG_SEARCH);

        if (f != null) {
            fm.beginTransaction()
                    .remove(f)
                    .commit();
        }

        searchContainer.setVisibility(View.GONE);
    }

    // Kata kunci disubmit:
    // simpan ke riwayat -> pindah ke Jelajahi -> tampilkan hasil
    public void submitSearch(String q) {

        SearchHistory.add(this, q);

        closeSearch();

        bottomNav.setSelectedItemId(ID_BROWSE);

        Fragment f = getSupportFragmentManager()
                .findFragmentByTag(TAGS[3]);

        if (f instanceof FeedFragment) {
            ((FeedFragment) f).showResults(q);
        }
    }

    // Dipanggil MoreFragment setelah bahasa chapter diganti,
    // supaya Beranda & Jelajahi dimuat ulang dengan bahasa baru
    // dan manhwa yang tidak punya chapter di bahasa itu langsung hilang dari daftar.
    public void refreshFeeds() {

        FragmentManager fm = getSupportFragmentManager();

        Fragment home = fm.findFragmentByTag(TAGS[0]);
        Fragment browse = fm.findFragmentByTag(TAGS[3]);

        if (home instanceof FeedFragment) {
            ((FeedFragment) home).reload();
        }

        if (browse instanceof FeedFragment) {
            ((FeedFragment) browse).reload();
        }
    }

    // Dipakai semua fragment tab:
    // tampilkan ikon search di bar atas dan hubungkan kliknya.
    public static void bindSearchButton(
            final Fragment f,
            View root
    ) {

        ImageView btn = root.findViewById(R.id.btn_open_search);

        btn.setVisibility(View.VISIBLE);

        btn.setImageDrawable(
                Icons.get(root.getContext(), Icons.SEARCH)
        );

        btn.setColorFilter(0xFFE6E1E5);

        btn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (f.getActivity() instanceof MainActivity) {

                            ((MainActivity) f.getActivity())
                                    .openSearch("");
                        }
                    }
                }
        );
    }

    @Override
    public void onBackPressed() {

        if (searchOpen) {

            closeSearch();

        } else if (currentId != ID_HOME) {

            bottomNav.setSelectedItemId(ID_HOME);

        } else {

            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putInt("tab", currentId);
    }
}