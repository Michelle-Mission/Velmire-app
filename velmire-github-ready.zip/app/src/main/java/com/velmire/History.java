package com.velmire;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

public class History {

    // Data manhwa yang ikut dibawa ke reader dan riwayat
    public static final String[] META = {
            "title", "coverUrl", "description", "status", "year", "tags"
    };

    private static final String PREFS = "velmire_prefs";
    private static final String KEY = "history";
    private static final int MAX = 100;
    private static final String[] FIELDS = {
            "id", "title", "coverUrl", "description", "status", "year", "tags",
            "chapterId", "chapterTitle", "chapterIndex", "page", "time"
    };

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // Terbaru dibaca ada di urutan pertama
    public static ArrayList<HashMap<String, String>> getAll(Context c) {
        ArrayList<HashMap<String, String>> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                HashMap<String, String> m = new HashMap<>();
                for (String f : FIELDS) m.put(f, o.optString(f, ""));
                out.add(m);
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static HashMap<String, String> get(Context c, String mangaId) {
        if (mangaId == null) return null;
        for (HashMap<String, String> m : getAll(c)) {
            if (mangaId.equals(m.get("id"))) return m;
        }
        return null;
    }

    public static void record(Context c, HashMap<String, String> manga, String chapterId,
                              String chapterTitle, int chapterIndex, int page) {
        String id = manga.get("id");
        if (id == null || id.isEmpty()) return;

        HashMap<String, String> e = new HashMap<>();
        e.put("id", id);
        for (String k : META) e.put(k, manga.get(k) == null ? "" : manga.get(k));
        e.put("chapterId", chapterId == null ? "" : chapterId);
        e.put("chapterTitle", chapterTitle == null ? "" : chapterTitle);
        e.put("chapterIndex", String.valueOf(chapterIndex));
        e.put("page", String.valueOf(page));
        e.put("time", String.valueOf(System.currentTimeMillis()));

        ArrayList<HashMap<String, String>> list = getAll(c);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (id.equals(list.get(i).get("id"))) list.remove(i);
        }
        list.add(0, e);
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(c, list);
    }

    public static void remove(Context c, String id) {
        if (id == null) return;
        ArrayList<HashMap<String, String>> list = getAll(c);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (id.equals(list.get(i).get("id"))) list.remove(i);
        }
        save(c, list);
    }

    public static void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
    }

    public static long num(String s) {
        try {
            return Long.parseLong(s);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String ago(long time) {
        long min = (System.currentTimeMillis() - time) / 60000L;
        if (min < 1) return "baru saja";
        if (min < 60) return min + " menit lalu";
        long h = min / 60;
        if (h < 24) return h + " jam lalu";
        long d = h / 24;
        if (d < 30) return d + " hari lalu";
        return (d / 30) + " bulan lalu";
    }

    private static void save(Context c, ArrayList<HashMap<String, String>> list) {
        JSONArray arr = new JSONArray();
        for (HashMap<String, String> m : list) {
            try {
                JSONObject o = new JSONObject();
                for (String f : FIELDS) o.put(f, m.get(f) == null ? "" : m.get(f));
                arr.put(o);
            } catch (Exception ignored) { }
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }
}