package com.velmire;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;

public class HistoryFragment extends Fragment {

    private final ArrayList<HashMap<String, String>> data = new ArrayList<>();
    private MangaAdapter adapter;
    private TextView btnAction;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final Context ctx = inflater.getContext();
        View root = inflater.inflate(R.layout.custom_list, container, false);

        TextView title = root.findViewById(R.id.txt_bar_title);
        title.setText("Riwayat");

        btnAction = root.findViewById(R.id.btn_bar_action);
        btnAction.setText("Hapus semua");
        btnAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() == null) return;
                new AlertDialog.Builder(getActivity(), AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setMessage("Hapus semua riwayat baca?")
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                History.clear(ctx);
                                refresh();
                            }
                        })
                        .show();
            }
        });

        ListView list = root.findViewById(R.id.list_main);
        TextView empty = root.findViewById(R.id.txt_empty);
        empty.setText("Belum ada riwayat\nManhwa yang kamu baca akan muncul di sini.");

        adapter = new MangaAdapter(ctx, data) {
            @Override
            protected String subtitle(HashMap<String, String> m) {
                int page = (int) History.num(m.get("page")) + 1;
                return m.get("chapterTitle") + " (hal. " + page + ")\n"
                        + History.ago(History.num(m.get("time")));
            }
        };
        list.setAdapter(adapter);
        list.setEmptyView(empty);

        // Tap = langsung lanjut baca dari chapter dan halaman terakhir
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= data.size()) return;
                MangaAdapter.openDetail(ctx, data.get(position), true);
            }
        });

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= data.size() || getActivity() == null) return true;
                final HashMap<String, String> m = data.get(position);
                new AlertDialog.Builder(getActivity(), AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle(m.get("title"))
                        .setMessage("Hapus dari riwayat?")
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                History.remove(ctx, m.get("id"));
                                refresh();
                            }
                        })
                        .show();
                return true;
            }
        });

        refresh();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) refresh();
    }

    private void refresh() {
        if (getContext() == null || adapter == null) return;
        data.clear();
        data.addAll(History.getAll(getContext()));
        adapter.notifyDataSetChanged();
        btnAction.setVisibility(data.isEmpty() ? View.GONE : View.VISIBLE);
    }
}