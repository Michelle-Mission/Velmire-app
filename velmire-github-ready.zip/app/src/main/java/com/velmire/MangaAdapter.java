package com.velmire;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MangaAdapter extends BaseAdapter {

    private final Context context;
    private final ArrayList<HashMap<String, String>> data;
    private final Net.Callback coverCallback;
    private boolean errorShown = false;

    public MangaAdapter(final Context ctx, ArrayList<HashMap<String, String>> data) {
        this.context = ctx;
        this.data = data;

        this.coverCallback = new Net.Callback() {
            @Override
            public void onLoaded(Bitmap bitmap) {
                // Cover berhasil dimuat.
            }

            @Override
            public void onFailed(String reason) {
                if (!errorShown) {
                    errorShown = true;

                    Toast.makeText(
                            ctx,
                            "Cover gagal dimuat: " + reason,
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }
        };
    }

    // Teks kecil di bawah judul.
    // Bisa di-override, misalnya untuk adapter Riwayat.
    protected String subtitle(HashMap<String, String> m) {
        String label = statusLabel(m.get("status"));
        return label.isEmpty() ? "Manhwa" : label;
    }

    public static String statusLabel(String s) {
        if ("ongoing".equals(s)) {
            return "Berlanjut";
        }

        if ("completed".equals(s)) {
            return "Tamat";
        }

        if ("hiatus".equals(s)) {
            return "Hiatus";
        }

        if ("cancelled".equals(s)) {
            return "Dibatalkan";
        }

        return "";
    }

    public static void openDetail(
            Context c,
            HashMap<String, String> m,
            boolean autoResume
    ) {
        Intent intent = new Intent(c, DetailActivity.class);

        intent.putExtra("manga_id", m.get("id"));
        intent.putExtra("manga_title", m.get("title"));
        intent.putExtra("cover_url", m.get("coverUrl"));
        intent.putExtra("description", m.get("description"));
        intent.putExtra("status", m.get("status"));
        intent.putExtra("year", m.get("year"));
        intent.putExtra("tags", m.get("tags"));
        intent.putExtra("auto_resume", autoResume);

        c.startActivity(intent);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(
            int position,
            View convertView,
            ViewGroup parent
    ) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.custom_manga, parent, false);
        }

        TextView txt_title =
                convertView.findViewById(R.id.txt_title);

        TextView txt_sub =
                convertView.findViewById(R.id.textview2);

        ImageView img_cover =
                convertView.findViewById(R.id.img_cover);

        // Data untuk row saat ini
        HashMap<String, String> current = data.get(position);

        // Set teks baru
        txt_title.setText(current.get("title"));
        txt_sub.setText(subtitle(current));

        // FIX:
        // Reset cover lama sebelum mulai memuat cover baru.
        // Ini mencegah cover dari row sebelumnya ikut terbawa
        // ketika convertView di-recycle.
        img_cover.setImageDrawable(null);

        // Pastikan tipe scaling cover tetap sesuai.
        img_cover.setScaleType(ImageView.ScaleType.CENTER_CROP);

        // Load cover untuk item saat ini.
        Net.loadImage(
                context,
                current.get("coverUrl"),
                img_cover,
                300,
                false,
                coverCallback
        );

        return convertView;
    }
}
