package com.velmire;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;

public class LibraryFragment extends Fragment {

    private final ArrayList<HashMap<String, String>> data = new ArrayList<>();
    private MangaAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final Context ctx = inflater.getContext();
        View root = inflater.inflate(R.layout.custom_list, container, false);

        TextView title = root.findViewById(R.id.txt_bar_title);
        title.setText("Pustaka");

        ListView list = root.findViewById(R.id.list_main);
        TextView empty = root.findViewById(R.id.txt_empty);
        empty.setText("Pustaka masih kosong\nBuka detail manhwa lalu tap Tambah ke perpustakaan.");

        adapter = new MangaAdapter(ctx, data);
        list.setAdapter(adapter);
        list.setEmptyView(empty);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= data.size()) return;
                MangaAdapter.openDetail(ctx, data.get(position), false);
            }
        });

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= data.size() || getActivity() == null) return true;
                final HashMap<String, String> m = data.get(position);
                new AlertDialog.Builder(getActivity(), AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle(m.get("title"))
                        .setMessage("Hapus dari perpustakaan?")
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Library.remove(ctx, m.get("id"));
                                refresh();
                            }
                        })
                        .show();
                return true;
            }
        });

        refresh();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) refresh();
    }

    private void refresh() {
        if (getContext() == null || adapter == null) return;
        data.clear();
        data.addAll(Library.getAll(getContext()));
        adapter.notifyDataSetChanged();
    }
}