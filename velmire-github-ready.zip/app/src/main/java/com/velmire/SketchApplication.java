package com.velmire;

import android.app.Application;

/**
 * Minimal application class kept for compatibility with the manifest.
 *
 * The original source archive referenced this class but did not include it.
 * Add application-wide initialization here when the project needs it.
 */
public class SketchApplication extends Application {
}
