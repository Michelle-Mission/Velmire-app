package com.velmire;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class DetailActivity extends AppCompatActivity {

    private ListView listview_chapter;

    // Semua chapter, semua bahasa, tanpa dedup -- disimpan mentah dari API
    // (hanya diisi kalau setting global bahasa = Semua Bahasa; kalau setting
    // global sudah spesifik, API sendiri sudah cuma balikin 1 bahasa)
    private final ArrayList<HashMap<String, String>> allChapters = new ArrayList<>();

    // Kode bahasa yang benar-benar tersedia untuk manhwa ini, urutannya
    // mengikuti urutan Settings.LANGUAGES biar konsisten
    private final ArrayList<String> availableLangs = new ArrayList<>();

    // Filter bahasa khusus untuk manhwa ini saja (beda dari Net.CHAPTER_LANG
    // yang global). Cuma relevan kalau Net.CHAPTER_LANG == LANG_ALL.
    private String localLangFilter = Settings.LANG_ALL;

    // Urutan asli: lama -> baru, setelah difilter+dedup sesuai localLangFilter
    // Dipakai oleh Reader
    private final ArrayList<HashMap<String, String>> masterAsc = new ArrayList<>();

    // Urutan yang sedang ditampilkan di ListView
    private final ArrayList<HashMap<String, String>> displayList = new ArrayList<>();

    private ChapterAdapter adapter;
    private TextView sortText;
    private TextView langFilterText;
    private TextView favButton;
    private TextView resumeButton;

    private SharedPreferences prefs;
    private Set<String> readIds = new HashSet<>();

    // Data manhwa untuk perpustakaan, reader, dan riwayat
    private final HashMap<String, String> mangaData = new HashMap<>();

    private String mangaId = "";
    private boolean newestFirst = true;
    private boolean loaded = false;
    private boolean fetchFailed = false;
    private boolean autoResume = false;

    private int resumeIdx = -1;
    private int resumePage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);

        listview_chapter = findViewById(R.id.listview_chapter);

        TextView txt_detail_title = findViewById(R.id.txt_detail_title);
        TextView txt_status = findViewById(R.id.textview5);
        ImageView img_detail_cover = findViewById(R.id.img_detail_cover);

        Intent in = getIntent();

        mangaId = in.getStringExtra("manga_id");

        if (mangaId == null || mangaId.isEmpty()) {
            Toast.makeText(
                    this,
                    "ID manhwa tidak valid",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        prefs = getSharedPreferences(
                "velmire_prefs",
                MODE_PRIVATE
        );

        autoResume = in.getBooleanExtra(
                "auto_resume",
                false
        );

        String title = nz(in.getStringExtra("manga_title"));
        String coverUrl = nz(in.getStringExtra("cover_url"));
        String description = nz(in.getStringExtra("description"));
        String status = nz(in.getStringExtra("status"));
        String year = nz(in.getStringExtra("year"));
        String tags = nz(in.getStringExtra("tags"));

        mangaData.put("id", mangaId);
        mangaData.put("title", title);
        mangaData.put("coverUrl", coverUrl);
        mangaData.put("description", description);
        mangaData.put("status", status);
        mangaData.put("year", year);
        mangaData.put("tags", tags);

        txt_detail_title.setText(title);

        String statusLine = buildStatusLine(status, year);

        if (statusLine.isEmpty()) {
            txt_status.setVisibility(View.GONE);
        } else {
            txt_status.setText(statusLine);
        }

        if (!coverUrl.isEmpty()) {
            img_detail_cover.setScaleType(
                    ImageView.ScaleType.CENTER_CROP
            );

            Net.loadImage(
                    this,
                    coverUrl.replace(".256.jpg", ".512.jpg"),
                    img_detail_cover,
                    512,
                    false,
                    null
            );
        }

        View header = buildHeader(tags, description);

        listview_chapter.addHeaderView(
                header,
                null,
                false
        );

        adapter = new ChapterAdapter();
        listview_chapter.setAdapter(adapter);

        listview_chapter.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        int p = position
                                - listview_chapter.getHeaderViewsCount();

                        if (p < 0 || p >= displayList.size()) {
                            return;
                        }

                        String idxString =
                                displayList.get(p).get("idx");

                        if (idxString == null) {
                            return;
                        }

                        try {
                            int idx = Integer.parseInt(idxString);
                            openReader(idx, 0);
                        } catch (NumberFormatException ignored) {
                            // Data chapter tidak valid
                        }
                    }
                }
        );

        fetchChapters();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (prefs == null) {
            return;
        }

        readIds = new HashSet<>(
                prefs.getStringSet(
                        "read_" + mangaId,
                        new HashSet<String>()
                )
        );

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        if (loaded) {
            updateResumeButton();
        }
    }

    private String nz(String s) {
        return s == null ? "" : s;
    }

    // ---------- Header ----------

    private View buildHeader(String tags, String desc) {

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        box.setPadding(
                Net.dp(this, 16),
                Net.dp(this, 12),
                Net.dp(this, 16),
                Net.dp(this, 8)
        );

        // ---------- Favorit ----------

        favButton = new TextView(this);
        favButton.setGravity(Gravity.CENTER);
        favButton.setTextSize(13);

        favButton.setTypeface(
                Typeface.create(
                        "sans-serif-medium",
                        Typeface.NORMAL
                )
        );

        favButton.setPadding(
                Net.dp(this, 20),
                0,
                Net.dp(this, 20),
                0
        );

        favButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        boolean nowIn =
                                Library.toggle(
                                        DetailActivity.this,
                                        mangaData
                                );

                        updateFavButton();

                        Toast.makeText(
                                DetailActivity.this,
                                nowIn
                                        ? "Ditambahkan ke perpustakaan"
                                        : "Dihapus dari perpustakaan",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
        );

        LinearLayout.LayoutParams flp =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        Net.dp(this, 44)
                );

        flp.bottomMargin = Net.dp(this, 12);

        box.addView(favButton, flp);

        updateFavButton();

        // ---------- Resume ----------

        resumeButton = new TextView(this);
        resumeButton.setGravity(Gravity.CENTER);
        resumeButton.setTextSize(13);

        resumeButton.setTypeface(
                Typeface.create(
                        "sans-serif-medium",
                        Typeface.NORMAL
                )
        );

        resumeButton.setTextColor(0xFF0B1B33);

        resumeButton.setPadding(
                Net.dp(this, 20),
                0,
                Net.dp(this, 20),
                0
        );

        GradientDrawable rbg = new GradientDrawable();
        rbg.setCornerRadius(Net.dp(this, 22));
        rbg.setColor(0xFF8AB4F8);

        resumeButton.setBackground(rbg);
        resumeButton.setVisibility(View.GONE);

        resumeButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (resumeIdx >= 0) {
                            openReader(
                                    resumeIdx,
                                    resumePage
                            );
                        }
                    }
                }
        );

        LinearLayout.LayoutParams rlp =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        Net.dp(this, 44)
                );

        rlp.bottomMargin = Net.dp(this, 12);

        box.addView(resumeButton, rlp);

        // ---------- Genre ----------

        if (tags != null && !tags.isEmpty()) {

            TextView infoText = new TextView(this);

            infoText.setTextColor(0xFFA6A6AB);
            infoText.setTextSize(13);
            infoText.setText(tags);

            box.addView(
                    infoText,
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            );
        }

        // ---------- Sinopsis ----------

        if (desc != null && !desc.trim().isEmpty()) {

            final TextView descText = new TextView(this);

            descText.setTextColor(0xFFE6E1E5);
            descText.setTextSize(14);
            descText.setLineSpacing(0, 1.15f);
            descText.setText(desc.trim());

            descText.setMaxLines(4);
            descText.setEllipsize(
                    TextUtils.TruncateAt.END
            );

            descText.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            descText.setMaxLines(
                                    descText.getMaxLines() == 4
                                            ? Integer.MAX_VALUE
                                            : 4
                            );
                        }
                    }
            );

            LinearLayout.LayoutParams lp =
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    );

            lp.topMargin = Net.dp(this, 8);

            box.addView(descText, lp);
        }

        // ---------- Filter bahasa (khusus manhwa ini, hanya muncul kalau
        // setting global = Semua Bahasa DAN manhwa ini punya >1 bahasa) ----------

        langFilterText = new TextView(this);
        langFilterText.setTextColor(0xFF8AB4F8);
        langFilterText.setTextSize(13);
        langFilterText.setTypeface(
                Typeface.create("sans-serif-medium", Typeface.NORMAL)
        );
        langFilterText.setPadding(
                0,
                Net.dp(this, 14),
                0,
                0
        );
        langFilterText.setVisibility(View.GONE);
        langFilterText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLocalLangDialog();
            }
        });

        box.addView(
                langFilterText,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        // ---------- Sort ----------

        sortText = new TextView(this);

        sortText.setTextColor(0xFF8AB4F8);
        sortText.setTextSize(14);

        sortText.setTypeface(
                Typeface.create(
                        "sans-serif-medium",
                        Typeface.NORMAL
                )
        );

        sortText.setPadding(
                0,
                Net.dp(this, 12),
                0,
                Net.dp(this, 4)
        );

        sortText.setText("Memuat chapter...");

        sortText.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (fetchFailed) {
                            fetchFailed = false;
                            sortText.setText(
                                    "Memuat chapter..."
                            );
                            fetchChapters();
                            return;
                        }

                        if (!loaded) {
                            return;
                        }

                        if (masterAsc.isEmpty()) {
                            fetchFailed = false;
                            sortText.setText(
                                    "Memuat chapter..."
                            );
                            fetchChapters();
                            return;
                        }

                        newestFirst = !newestFirst;
                        rebuildDisplay();
                    }
                }
        );

        box.addView(
                sortText,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        return box;
    }

    private void updateFavButton() {

        boolean inLib =
                Library.contains(this, mangaId);

        GradientDrawable bg =
                new GradientDrawable();

        bg.setCornerRadius(
                Net.dp(this, 22)
        );

        bg.setColor(
                inLib
                        ? 0xFF2A3A55
                        : 0xFF262628
        );

        favButton.setBackground(bg);

        favButton.setTextColor(
                inLib
                        ? 0xFFD6E3FF
                        : 0xFFE6E1E5
        );

        favButton.setText(
                inLib
                        ? "Di perpustakaan"
                        : "Tambah ke perpustakaan"
        );
    }

    // ---------- Filter bahasa per-manhwa ----------

    private void updateLangFilterVisibility() {
        if (langFilterText == null) return;

        boolean eligible = Settings.LANG_ALL.equals(Net.CHAPTER_LANG)
                && availableLangs.size() > 1;

        if (!eligible) {
            langFilterText.setVisibility(View.GONE);
            return;
        }

        langFilterText.setVisibility(View.VISIBLE);
        String label = Settings.LANG_ALL.equals(localLangFilter)
                ? "Semua Bahasa"
                : Settings.labelFor(localLangFilter);
        langFilterText.setText("Bahasa: " + label + "  (ketuk untuk ganti)");
    }

    private void showLocalLangDialog() {
        if (availableLangs.size() <= 1) return;

        String[] labels = new String[availableLangs.size() + 1];
        labels[0] = "Semua Bahasa";
        int checkedIdx = 0;
        for (int i = 0; i < availableLangs.size(); i++) {
            labels[i + 1] = Settings.labelFor(availableLangs.get(i));
            if (availableLangs.get(i).equals(localLangFilter)) {
                checkedIdx = i + 1;
            }
        }

        new android.app.AlertDialog.Builder(
                this,
                android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK
        )
                .setTitle("Bahasa chapter untuk manhwa ini")
                .setSingleChoiceItems(
                        labels,
                        checkedIdx,
                        new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(
                                    android.content.DialogInterface dialog,
                                    int which
                            ) {
                                localLangFilter = (which == 0)
                                        ? Settings.LANG_ALL
                                        : availableLangs.get(which - 1);

                                dialog.dismiss();

                                buildMaster();
                                rebuildDisplay();
                                updateLangFilterVisibility();
                                updateResumeButton();
                            }
                        }
                )
                .setNegativeButton("Batal", null)
                .show();
    }

    // ---------- Resume ----------

    private void updateResumeButton() {

        HashMap<String, String> h =
                History.get(this, mangaId);

        int idx = -1;

        if (h != null) {

            String cid = h.get("chapterId");

            if (cid != null) {

                for (int i = 0; i < masterAsc.size(); i++) {

                    String chapterId =
                            masterAsc.get(i).get("id");

                    if (cid.equals(chapterId)) {
                        idx = i;
                        break;
                    }
                }
            }
        }

        if (h == null || idx < 0) {

            resumeIdx = -1;
            resumePage = 0;

            resumeButton.setVisibility(
                    View.GONE
            );

            return;
        }

        resumeIdx = idx;
        resumePage = (int) History.num(
                h.get("page")
        );

        resumeButton.setText(
                "Lanjutkan "
                        + shortLabel(
                                h.get("chapterTitle")
                        )
        );

        resumeButton.setVisibility(
                View.VISIBLE
        );
    }

    private String shortLabel(String t) {

        if (t == null) {
            return "";
        }

        int cut = t.indexOf(" - ");

        return cut > 0
                ? t.substring(0, cut)
                : t;
    }

    private String buildStatusLine(
            String status,
            String year
    ) {
        StringBuilder sb =
                new StringBuilder();

        String s =
                MangaAdapter.statusLabel(status);

        if (!s.isEmpty()) {
            sb.append(s);
        }

        if (year != null && !year.isEmpty()) {

            if (sb.length() > 0) {
                sb.append("  |  ");
            }

            sb.append(year);
        }

        return sb.toString();
    }

    private void updateSortText() {

        if (sortText == null) {
            return;
        }

        if (masterAsc.isEmpty()) {

            sortText.setText(
                    Settings.LANG_ALL.equals(Net.CHAPTER_LANG)
                            ? "Belum ada chapter"
                            : "Belum ada chapter ("
                                    + Net.CHAPTER_LANG.toUpperCase()
                                    + ")"
            );

            return;
        }

        sortText.setText(
                masterAsc.size()
                        + " chapter  |  "
                        + (newestFirst
                        ? "Terbaru dulu"
                        : "Terlama dulu")
                        + " (ketuk untuk ubah)"
        );
    }

    // Susun ulang masterAsc dari allChapters mentah, sesuai localLangFilter.
    // Dedup dilakukan per chapter number DI DALAM hasil filter, supaya kalau
    // user pilih 1 bahasa spesifik, tidak ada chapter number yang bentrok
    // (misal ada 2 grup translator ID yang sama-sama garap chapter 12).
    private void buildMaster() {

        masterAsc.clear();
        HashSet<String> seen = new HashSet<>();

        for (HashMap<String, String> ch : allChapters) {

            String lang = ch.get("lang");

            if (!Settings.LANG_ALL.equals(localLangFilter)
                    && !localLangFilter.equals(lang)) {
                continue;
            }

            String num = ch.get("num");
            String key = (num == null || num.isEmpty())
                    ? ch.get("id")
                    : num;

            if (!seen.add(key)) {
                continue;
            }

            HashMap<String, String> copy = new HashMap<>(ch);
            copy.put("idx", String.valueOf(masterAsc.size()));
            masterAsc.add(copy);
        }
    }

    private void rebuildDisplay() {

        displayList.clear();
        displayList.addAll(masterAsc);

        if (newestFirst) {
            Collections.reverse(displayList);
        }

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        updateSortText();
    }

    // ---------- Network ----------

    private void fetchChapters() {

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {

                    final ArrayList<HashMap<String, String>> all =
                            new ArrayList<>();

                    int offset = 0;
                    int total = Integer.MAX_VALUE;

                    while (offset < total) {

                        StringBuilder url = new StringBuilder(
                                "https://api.mangadex.org/manga/"
                                        + mangaId
                                        + "/feed?order%5Bchapter%5D=asc"
                                        + "&limit=500"
                                        + "&offset=" + offset
                        );

                        // FIX: "all" bukan kode bahasa valid buat MangaDex.
                        // Kalau global = Semua Bahasa, jangan kirim
                        // translatedLanguage[] sama sekali, biar semua bahasa
                        // ikut turun -- nanti dipilah di sisi app.
                        if (!Settings.LANG_ALL.equals(Net.CHAPTER_LANG)) {
                            url.append("&translatedLanguage%5B%5D=")
                                    .append(Net.CHAPTER_LANG);
                        }

                        String json = Net.get(url.toString());

                        JSONObject obj =
                                new JSONObject(json);

                        total = obj.optInt(
                                "total",
                                0
                        );

                        JSONArray data =
                                obj.optJSONArray("data");

                        if (data == null
                                || data.length() == 0) {
                            break;
                        }

                        for (int i = 0;
                                i < data.length();
                                i++) {

                            JSONObject ch =
                                    data.getJSONObject(i);

                            JSONObject attr =
                                    ch.getJSONObject(
                                            "attributes"
                                    );

                            // Lewati chapter eksternal
                            // atau tanpa halaman
                            if (!attr.isNull("externalUrl")
                                    || attr.optInt(
                                    "pages",
                                    0
                            ) <= 0) {
                                continue;
                            }

                            String id =
                                    ch.getString("id");

                            String num =
                                    attr.isNull("chapter")
                                            ? ""
                                            : attr.optString(
                                                    "chapter",
                                                    ""
                                            );

                            String lang =
                                    attr.optString(
                                            "translatedLanguage",
                                            ""
                                    );

                            String title =
                                    attr.isNull("title")
                                            ? ""
                                            : attr.optString(
                                                    "title",
                                                    ""
                                            ).trim();

                            String label =
                                    num.isEmpty()
                                            ? "Oneshot"
                                            : "Chapter " + num;

                            if (!title.isEmpty()) {
                                label += " - " + title;
                            }

                            // FIX: tidak dedup di sini lagi -- semua chapter
                            // (semua bahasa) disimpan mentah dulu, dedup per
                            // bahasa dilakukan belakangan di buildMaster().
                            HashMap<String, String> map =
                                    new HashMap<>();

                            map.put("id", id);
                            map.put("num", num);
                            map.put("lang", lang);
                            map.put(
                                    "display_title",
                                    label
                            );

                            all.add(map);
                        }

                        offset += data.length();
                    }

                    runOnUiThread(
                            new Runnable() {
                                @Override
                                public void run() {

                                    allChapters.clear();
                                    allChapters.addAll(all);

                                    // Hitung bahasa yang benar-benar tersedia,
                                    // urutannya ikut urutan Settings.LANGUAGES
                                    // biar konsisten dengan menu bahasa lain.
                                    HashSet<String> seenLangs = new HashSet<>();
                                    for (HashMap<String, String> ch : allChapters) {
                                        String l = ch.get("lang");
                                        if (l != null && !l.isEmpty()) {
                                            seenLangs.add(l);
                                        }
                                    }
                                    availableLangs.clear();
                                    for (String[] entry : Settings.LANGUAGES) {
                                        String code = entry[0];
                                        if (!Settings.LANG_ALL.equals(code)
                                                && seenLangs.contains(code)) {
                                            availableLangs.add(code);
                                        }
                                    }

                                    localLangFilter = Settings.LANG_ALL;

                                    buildMaster();

                                    loaded = true;
                                    fetchFailed = false;

                                    rebuildDisplay();
                                    updateLangFilterVisibility();

                                    // Jika tidak ada chapter,
                                    // tampilkan pesan sesuai bahasa.
                                    if (masterAsc.isEmpty()) {

                                        sortText.setText(
                                                Settings.LANG_ALL.equals(
                                                        Net.CHAPTER_LANG
                                                )
                                                        ? "Belum ada chapter"
                                                        : "Belum ada chapter ("
                                                                + Net.CHAPTER_LANG
                                                                .toUpperCase()
                                                                + ")"
                                        );
                                    }

                                    updateResumeButton();

                                    // Dibuka dari Riwayat
                                    // -> langsung lanjut baca
                                    if (autoResume
                                            && resumeIdx >= 0) {

                                        autoResume = false;

                                        openReader(
                                                resumeIdx,
                                                resumePage
                                        );
                                    }
                                }
                            }
                    );

                } catch (final Exception e) {

                    runOnUiThread(
                            new Runnable() {
                                @Override
                                public void run() {

                                    fetchFailed = true;

                                    sortText.setText(
                                            "Gagal memuat: "
                                                    + Net.describe(e)
                                                    + " (ketuk untuk coba lagi)"
                                    );
                                }
                            }
                    );
                }
            }
        }).start();
    }

    // ---------- Reader ----------

    private void openReader(
            int idx,
            int page
    ) {

        String[] ids =
                new String[masterAsc.size()];

        String[] titles =
                new String[masterAsc.size()];

        for (int i = 0;
                i < masterAsc.size();
                i++) {

            ids[i] =
                    masterAsc.get(i).get("id");

            titles[i] =
                    masterAsc.get(i).get(
                            "display_title"
                    );
        }

        Intent intent =
                new Intent(
                        this,
                        ReadActivity.class
                );

        intent.putExtra(
                "manga_id",
                mangaId
        );

        intent.putExtra(
                "chapter_ids",
                ids
        );

        intent.putExtra(
                "chapter_titles",
                titles
        );

        intent.putExtra(
                "index",
                idx
        );

        intent.putExtra(
                "start_page",
                page
        );

        for (String k : History.META) {

            intent.putExtra(
                    "m_" + k,
                    mangaData.get(k)
            );
        }

        startActivity(intent);
    }

    // ---------- Adapter ----------

    private class ChapterAdapter
            extends BaseAdapter {

        @Override
        public int getCount() {
            return displayList.size();
        }

        @Override
        public Object getItem(int position) {
            return displayList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(
                int position,
                View convertView,
                ViewGroup parent
        ) {

            if (convertView == null) {

                convertView =
                        LayoutInflater.from(
                                DetailActivity.this
                        ).inflate(
                                R.layout.custom_chapter,
                                parent,
                                false
                        );
            }

            TextView txt =
                    convertView.findViewById(
                            R.id.txt_chapter_title
                    );

            HashMap<String, String> item =
                    displayList.get(position);

            String title =
                    item.get("display_title");

            txt.setText(
                    title == null
                            ? ""
                            : title
            );

            // Chapter yang sudah dibaca dibuat redup
            txt.setAlpha(
                    readIds.contains(
                            item.get("id")
                    )
                            ? 0.45f
                            : 1f
            );

            return convertView;
        }
    }
}