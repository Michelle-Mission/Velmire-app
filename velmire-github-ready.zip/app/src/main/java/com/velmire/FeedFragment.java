package com.velmire;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class FeedFragment extends Fragment {

    private static final int PAGE_SIZE = 20;
    private static final String ARG_BROWSE = "browse";

    // Batas jaga-jaga: berapa kali maksimal auto-lanjut ambil halaman berikutnya
    // dalam satu kali startSearch(), supaya kalau bahasa yang dipilih memang
    // sangat jarang tersedia, app tidak spam request tanpa henti.
    private static final int MAX_AUTO_FILL_ROUNDS = 4;

    private static final String[] SORT_KEYS = {"followedCount", "latestUploadedChapter", "rating"};
    private static final String[] SORT_LABELS = {"Populer", "Update Terbaru", "Rating"};
    private static final String[] STATUS_KEYS = {"", "ongoing", "completed", "hiatus", "cancelled"};
    private static final String[] STATUS_LABELS = {"Semua Status", "Ongoing", "Completed", "Hiatus", "Cancelled"};

    // browse=false -> Beranda (populer)
    // browse=true  -> Jelajahi (kosong, hanya menampilkan hasil pencarian)
    public static FeedFragment newInstance(boolean browse) {
        FeedFragment f = new FeedFragment();
        Bundle b = new Bundle();
        b.putBoolean(ARG_BROWSE, browse);
        f.setArguments(b);
        return f;
    }

    private boolean browse = false;
    private boolean started = false;
    private Context ctx;
    private ListView list;
    private TextView footer, txtTitle, txtEmpty, btnClear;
    private final ArrayList<HashMap<String, String>> data = new ArrayList<>();
    private MangaAdapter adapter;

    private String currentQuery = "";
    private int offset = 0;
    private boolean loading = false;
    private boolean hasMore = true;
    private boolean errored = false;
    private int requestId = 0;
    private int autoFillRounds = 0;

    // ---------- Filter & urutan ----------
    private TextView btnSort, btnStatus, btnGenre;
    private int sortIndex = 0;
    private boolean sortManuallyChanged = false;
    private int statusIndex = 0;
    private final ArrayList<MangaTags.Tag> allGenres = new ArrayList<>();
    private final HashSet<String> selectedGenreIds = new HashSet<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        browse = args != null && args.getBoolean(ARG_BROWSE, false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ctx = inflater.getContext();
        started = false;
        currentQuery = "";
        data.clear();

        View root = inflater.inflate(R.layout.custom_list, container, false);
        txtTitle = root.findViewById(R.id.txt_bar_title);
        txtEmpty = root.findViewById(R.id.txt_empty);
        btnClear = root.findViewById(R.id.btn_bar_action);
        list = root.findViewById(R.id.list_main);

        MainActivity.bindSearchButton(this, root);

        footer = new TextView(ctx);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, Net.dp(ctx, 16), 0, Net.dp(ctx, 24));
        footer.setTextColor(0xFF8E8E93);
        footer.setTextSize(13);
        footer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (errored) {
                    errored = false;
                    loadMore();
                }
            }
        });

        list.addHeaderView(buildFilterBar(), null, false);
        list.addFooterView(footer, null, false);

        adapter = new MangaAdapter(ctx, data);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // FIX: kurangi jumlah header view, karena addHeaderView() bikin
                // ListView menghitung header sebagai posisi 0, jadi tanpa ini
                // klik item pertama membuka data index kedua (offset 1).
                int dataPosition = position - list.getHeaderViewsCount();
                if (dataPosition < 0 || dataPosition >= data.size()) return;
                MangaAdapter.openDetail(ctx, data.get(dataPosition), false);
            }
        });

        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) { }

            @Override
            public void onScroll(AbsListView view, int first, int visible, int total) {
                if (total > 0 && first + visible >= total - 3) loadMore();
            }
        });

        if (browse) {
            txtTitle.setSingleLine(true);
            txtTitle.setEllipsize(TextUtils.TruncateAt.END);

            btnClear.setText("Hapus");
            btnClear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clearResults();
                }
            });

            // Ikon search dan judul di Jelajahi membuka pencarian dengan kata kunci saat ini
            View.OnClickListener openWithQuery = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).openSearch(currentQuery);
                    }
                }
            };
            ImageView btnSearch = root.findViewById(R.id.btn_open_search);
            btnSearch.setOnClickListener(openWithQuery);
            txtTitle.setOnClickListener(openWithQuery);

            txtEmpty.setText("Cari manhwa\nTap ikon search di kanan atas untuk mulai mencari.");
            showEmptyState();
        } else {
            txtTitle.setText("Beranda");
        }
        updateBar();
        return root;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (!browse && !isHidden()) ensureStarted();
    }

    @Override
    public void onResume() {
        super.onResume();
        // FIX: fragment tab ini nggak pernah di-destroy, cuma di-hide/show
        // lewat MainActivity, jadi highlight abu-abu bekas tap di ListView
        // suka nyangkut kalau balik dari DetailActivity. Dipaksa redraw di sini.
        if (list != null) list.invalidateViews();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden && !browse) ensureStarted();
    }

    // Beranda dimuat sekali saat pertama tampil
    private void ensureStarted() {
        if (started) return;
        started = true;
        startSearch("");
    }

    // Dipanggil dari luar (MainActivity) saat bahasa chapter diganti di menu Lainnya,
    // supaya daftar manhwa yang sedang tampil dimuat ulang pakai bahasa baru,
    // bukan tetap menampilkan hasil lama yang di-fetch dengan bahasa sebelumnya.
    public void reload() {
        if (list == null) return;
        if (browse) {
            // Jelajahi: cuma reload kalau lagi ada hasil pencarian yang ditampilkan
            if (!currentQuery.isEmpty()) {
                startSearch(currentQuery);
            }
        } else {
            // Beranda: selalu reload
            started = true;
            startSearch("");
        }
    }

    // ---------- Jelajahi: hanya hasil pencarian ----------

    // Dipanggil MainActivity setelah user submit kata kunci
    public void showResults(String q) {
        if (!browse || list == null) return;
        txtEmpty.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
        startSearch(q);
        updateBar();
    }

    private void clearResults() {
        requestId++; // batalkan request yang masih berjalan
        currentQuery = "";
        loading = false;
        hasMore = false;
        errored = false;
        data.clear();
        adapter.notifyDataSetChanged();
        showEmptyState();
        updateBar();
    }

    private void showEmptyState() {
        list.setVisibility(View.GONE);
        txtEmpty.setVisibility(View.VISIBLE);
    }

    private void updateBar() {
        if (!browse) return;
        boolean has = !currentQuery.isEmpty();
        txtTitle.setText(has ? currentQuery : "Jelajahi");
        btnClear.setVisibility(has ? View.VISIBLE : View.GONE);
    }

    // ---------- Load data ----------

    private void startSearch(String q) {
        currentQuery = q;
        offset = 0;
        hasMore = true;
        errored = false;
        loading = false;
        autoFillRounds = 0;
        requestId++;
        data.clear();
        adapter.notifyDataSetChanged();
        list.setSelection(0);
        loadMore();
    }

    private void loadMore() {
        if (loading || !hasMore || errored) return;
        final FragmentActivity act = getActivity();
        if (act == null) return;
        loading = true;
        footer.setText("Memuat...");

        final int myRequest = requestId;
        final int myOffset = offset;
        final String q = currentQuery;
        final String orderKey = (!sortManuallyChanged && !q.isEmpty()) ? "relevance" : SORT_KEYS[sortIndex];
        final String statusKey = STATUS_KEYS[statusIndex];
        final ArrayList<String> genreIds = new ArrayList<>(selectedGenreIds);
        final String filterLang = Net.CHAPTER_LANG;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    StringBuilder url = new StringBuilder("https://api.mangadex.org/manga"
        + "?originalLanguage%5B%5D=ko"
        + "&includes%5B%5D=cover_art"
        + "&contentRating%5B%5D=safe"
        + "&hasAvailableChapters=true"
        + "&limit=" + PAGE_SIZE
        + "&offset=" + myOffset
        + "&order%5B" + orderKey + "%5D=desc");
if (!Settings.LANG_ALL.equals(filterLang)) {
    url.append("&availableTranslatedLanguage%5B%5D=").append(filterLang);
}
                    if (!q.isEmpty()) {
                        url.append("&title=").append(URLEncoder.encode(q, "UTF-8"));
                    }
                    if (!statusKey.isEmpty()) {
                        url.append("&status%5B%5D=").append(statusKey);
                    }
                    if (!genreIds.isEmpty()) {
                        url.append("&includedTagsMode=AND");
                        for (String id : genreIds) {
                            url.append("&includedTags%5B%5D=").append(id);
                        }
                    }

                    JSONObject obj = new JSONObject(Net.get(url.toString()));
                    final int total = obj.optInt("total", 0);
                    JSONArray arr = obj.optJSONArray("data");
                    final int received = arr == null ? 0 : arr.length();
                    final ArrayList<HashMap<String, String>> page = new ArrayList<>();
                    for (int i = 0; i < received; i++) {
                        page.add(parseManga(arr.getJSONObject(i)));
                    }

                    // FIX: filter availableTranslatedLanguage[] MangaDex kadang tidak
                    // akurat (data cache server suka telat/salah update), jadi tiap
                    // manga hasil pencarian dicek ulang langsung ke data chapter
                    // aslinya lewat endpoint /aggregate sebelum ditampilkan.
                    final ArrayList<HashMap<String, String>> filteredPage =
                            filterByLanguage(page, filterLang);

                    act.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (myRequest != requestId || !isAdded()) return;
                            data.addAll(filteredPage);
                            offset = myOffset + received;
                            hasMore = received > 0 && offset < total && offset < 10000;
                            loading = false;
                            adapter.notifyDataSetChanged();
                            updateFooter();

                            // Kalau banyak yang kefilter dan layar jadi kelihatan
                            // kosong, otomatis ambil halaman berikutnya (dibatasi
                            // MAX_AUTO_FILL_ROUNDS biar tidak spam API).
                            boolean gotFilteredOut = filteredPage.size() < received;
                            if (gotFilteredOut && hasMore
                                    && data.size() < PAGE_SIZE
                                    && autoFillRounds < MAX_AUTO_FILL_ROUNDS) {
                                autoFillRounds++;
                                loadMore();
                            }
                        }
                    });
                } catch (final Exception e) {
                    act.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (myRequest != requestId || !isAdded()) return;
                            loading = false;
                            errored = true;
                            footer.setText("Gagal memuat: " + Net.describe(e)
                                    + "\nTap untuk coba lagi");
                        }
                    });
                }
            }
        }).start();
    }

    // Verifikasi ulang tiap manga langsung ke endpoint /aggregate (data chapter
    // asli), bukan cuma andalkan field availableTranslatedLanguage dari hasil
    // pencarian yang kadang tidak sinkron. Dijalankan paralel (6 sekaligus)
    // biar tidak terlalu lama nunggu.
    private ArrayList<HashMap<String, String>> filterByLanguage(
            final ArrayList<HashMap<String, String>> page,
            final String lang
    ) {
        if (Settings.LANG_ALL.equals(lang) || page.isEmpty()) {
            return page;
        }

        int poolSize = Math.min(6, page.size());
        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        List<Future<Boolean>> futures = new ArrayList<>();

        for (final HashMap<String, String> m : page) {
            futures.add(pool.submit(new Callable<Boolean>() {
                @Override
                public Boolean call() {
                    try {
                        String url = "https://api.mangadex.org/manga/"
                                + m.get("id")
                                + "/aggregate?translatedLanguage%5B%5D=" + lang;
                        JSONObject obj = new JSONObject(Net.get(url));
                        JSONObject volumes = obj.optJSONObject("volumes");
                        return volumes != null && volumes.length() > 0;
                    } catch (Exception e) {
                        // Gagal cek -> jangan dibuang, lebih aman drpd
                        // salah menyembunyikan manga yang sebenarnya valid.
                        return true;
                    }
                }
            }));
        }

        ArrayList<HashMap<String, String>> filtered = new ArrayList<>();
        for (int i = 0; i < page.size(); i++) {
            boolean keep;
            try {
                keep = futures.get(i).get();
            } catch (Exception e) {
                keep = true;
            }
            if (keep) filtered.add(page.get(i));
        }
        pool.shutdown();
        return filtered;
    }

    private void updateFooter() {
        if (data.isEmpty()) {
            footer.setText(currentQuery.isEmpty()
                    ? "Tidak ada data"
                    : "Tidak ada hasil untuk \"" + currentQuery + "\"");
        } else if (!hasMore) {
            footer.setText("- Sudah sampai akhir -");
        } else {
            footer.setText("");
        }
    }

    // ---------- Filter & Urutan (bar ditaruh sebagai header ListView) ----------

    private View buildFilterBar() {
        HorizontalScrollView scroll = new HorizontalScrollView(ctx);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setBackgroundColor(0xFF121212);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(Net.dp(ctx, 16), Net.dp(ctx, 12), Net.dp(ctx, 16), Net.dp(ctx, 12));

        btnSort = makeFilterChip(SORT_LABELS[sortIndex]);
        btnStatus = makeFilterChip(STATUS_LABELS[statusIndex]);
        btnGenre = makeFilterChip("Genre");

        btnSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { showSortDialog(); }
        });
        btnStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { showStatusDialog(); }
        });
        btnGenre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { showGenreDialog(); }
        });

        row.addView(btnSort, chipLp());
        row.addView(btnStatus, chipLp());
        row.addView(btnGenre, chipLp());

        scroll.addView(row);
        return scroll;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Net.dp(ctx, 8);
        return lp;
    }

    private TextView makeFilterChip(String text) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(0xFFE6E1E5);
        t.setTextSize(13);
        t.setPadding(Net.dp(ctx, 16), Net.dp(ctx, 8), Net.dp(ctx, 16), Net.dp(ctx, 8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF262628);
        bg.setCornerRadius(Net.dp(ctx, 20));
        t.setBackground(bg);
        return t;
    }

    private void updateFilterLabels() {
        if (btnSort == null) return;
        btnSort.setText(SORT_LABELS[sortIndex]);
        btnStatus.setText(STATUS_LABELS[statusIndex]);
        btnGenre.setText(selectedGenreIds.isEmpty() ? "Genre" : "Genre (" + selectedGenreIds.size() + ")");
    }

    private void showSortDialog() {
        if (ctx == null) return;
        new AlertDialog.Builder(ctx, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Urutkan")
                .setSingleChoiceItems(SORT_LABELS, sortIndex, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        sortIndex = which;
                        sortManuallyChanged = true;
                        dialog.dismiss();
                        updateFilterLabels();
                        startSearch(currentQuery);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showStatusDialog() {
        if (ctx == null) return;
        new AlertDialog.Builder(ctx, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Status")
                .setSingleChoiceItems(STATUS_LABELS, statusIndex, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        statusIndex = which;
                        dialog.dismiss();
                        updateFilterLabels();
                        startSearch(currentQuery);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showGenreDialog() {
        if (ctx == null) return;
        if (allGenres.isEmpty()) {
            Toast.makeText(ctx, "Memuat daftar genre...", Toast.LENGTH_SHORT).show();
            MangaTags.get(new MangaTags.Callback() {
                @Override
                public void onLoaded(ArrayList<MangaTags.Tag> tags) {
                    if (!isAdded()) return;
                    allGenres.clear();
                    allGenres.addAll(tags);
                    if (!allGenres.isEmpty()) showGenreDialog();
                    else Toast.makeText(ctx, "Genre tidak tersedia", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailed(String reason) {
                    if (!isAdded()) return;
                    Toast.makeText(ctx, "Gagal memuat genre: " + reason, Toast.LENGTH_SHORT).show();
                }
            });
            return;
        }

        final String[] names = new String[allGenres.size()];
        final boolean[] checked = new boolean[allGenres.size()];
        for (int i = 0; i < allGenres.size(); i++) {
            names[i] = allGenres.get(i).name;
            checked[i] = selectedGenreIds.contains(allGenres.get(i).id);
        }

        new AlertDialog.Builder(ctx, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Genre")
                .setMultiChoiceItems(names, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        String id = allGenres.get(which).id;
                        if (isChecked) selectedGenreIds.add(id); else selectedGenreIds.remove(id);
                    }
                })
                .setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectedGenreIds.clear();
                        updateFilterLabels();
                        startSearch(currentQuery);
                    }
                })
                .setNegativeButton("Batal", null)
                .setPositiveButton("Terapkan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        updateFilterLabels();
                        startSearch(currentQuery);
                    }
                })
                .show();
    }

    // ---------- Parsing ----------

    private HashMap<String, String> parseManga(JSONObject manga) throws Exception {
        HashMap<String, String> map = new HashMap<>();
        String id = manga.getString("id");
        map.put("id", id);

        JSONObject attributes = manga.getJSONObject("attributes");
        map.put("title", pickTitle(attributes));

        String desc = pickLocalized(attributes.optJSONObject("description"));
        int cut = desc.indexOf("\n---");
        if (cut > 0) desc = desc.substring(0, cut);
        map.put("description", desc.trim());

        map.put("status", attributes.optString("status", ""));
        int year = attributes.optInt("year", 0);
        map.put("year", year > 0 ? String.valueOf(year) : "");
        map.put("tags", pickTags(attributes.optJSONArray("tags")));

        String fileName = "";
        JSONArray rels = manga.optJSONArray("relationships");
        if (rels != null) {
            for (int j = 0; j < rels.length(); j++) {
                JSONObject rel = rels.getJSONObject(j);
                if ("cover_art".equals(rel.optString("type"))) {
                    JSONObject relAttr = rel.optJSONObject("attributes");
                    if (relAttr != null) fileName = relAttr.optString("fileName", "");
                    break;
                }
            }
        }
        map.put("coverUrl", fileName.isEmpty() ? ""
                : "https://uploads.mangadex.org/covers/" + id + "/" + fileName + ".256.jpg");
        return map;
    }

    // static: dipakai juga oleh SearchFragment untuk saran judul
    public static String pickTitle(JSONObject attributes) {
        String title = "";
        JSONObject titleObj = attributes.optJSONObject("title");
        if (titleObj != null) {
            title = titleObj.optString("en", "");
            if (title.isEmpty()) {
                JSONArray alts = attributes.optJSONArray("altTitles");
                if (alts != null) {
                    for (int i = 0; i < alts.length(); i++) {
                        JSONObject a = alts.optJSONObject(i);
                        if (a != null && !a.optString("en", "").isEmpty()) {
                            title = a.optString("en", "");
                            break;
                        }
                    }
                }
            }
            if (title.isEmpty()) {
                Iterator<String> keys = titleObj.keys();
                if (keys.hasNext()) title = titleObj.optString(keys.next(), "");
            }
        }
        return title.isEmpty() ? "No Title" : title;
    }

    private String pickLocalized(JSONObject obj) {
        if (obj == null) return "";
        String s = obj.optString("en", "");
        if (s.isEmpty()) {
            Iterator<String> keys = obj.keys();
            if (keys.hasNext()) s = obj.optString(keys.next(), "");
        }
        return s;
    }

    private String pickTags(JSONArray tags) {
        if (tags == null) return "";
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (int i = 0; i < tags.length() && count < 4; i++) {
            JSONObject t = tags.optJSONObject(i);
            if (t == null) continue;
            JSONObject a = t.optJSONObject("attributes");
            if (a == null) continue;
            JSONObject n = a.optJSONObject("name");
            if (n == null) continue;
            String name = n.optString("en", "");
            if (name.isEmpty()) continue;
            if (count > 0) sb.append(", ");
            sb.append(name);
            count++;
        }
        return sb.toString();
    }
}