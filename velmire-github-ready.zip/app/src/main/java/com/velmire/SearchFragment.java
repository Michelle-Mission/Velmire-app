package com.velmire;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;

public class SearchFragment extends Fragment {

    private static final String ARG_PREFILL = "prefill";
    private static final int MAX_SUGGEST = 8;
    private static final int MAX_ROWS = 10;

    private static final int T_HISTORY = 0;
    private static final int T_SUGGEST = 1;
    private static final int T_CLEAR_ALL = 2;

    public static SearchFragment newInstance(String prefill) {
        SearchFragment f = new SearchFragment();
        Bundle b = new Bundle();
        b.putString(ARG_PREFILL, prefill == null ? "" : prefill);
        f.setArguments(b);
        return f;
    }

    private static class Row {
        final int type;
        final String text;

        Row(int type, String text) {
            this.type = type;
            this.text = text;
        }
    }

    private static class Holder {
        ImageView lead;
        TextView label;
        ImageView trail;
    }

    private Context ctx;
    private EditText edit;
    private ImageView btnClear;
    private ListView list;
    private TextView empty;
    private RowAdapter adapter;
    private Drawable icHistory, icSearch, icClose, icFill;

    private final ArrayList<Row> rows = new ArrayList<>();
    private final ArrayList<String> remoteTitles = new ArrayList<>();

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pending;
    private int suggestToken = 0;

    private int dp(int v) {
        return Net.dp(ctx, v);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ctx = inflater.getContext();
        icHistory = Icons.get(ctx, Icons.HISTORY);
        icSearch = Icons.get(ctx, Icons.SEARCH);
        icClose = Icons.get(ctx, Icons.CLOSE);
        icFill = Icons.get(ctx, Icons.FILL);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);

        // ---- Bar atas: kembali | kolom cari | hapus teks ----
        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF191919);
        bar.setPadding(dp(4), 0, dp(8), 0);
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));

        ImageView back = iconButton(Icons.BACK);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).closeSearch();
                }
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        edit = new EditText(ctx);
        edit.setSingleLine(true);
        edit.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        edit.setHint("Cari manhwa");
        edit.setHintTextColor(0xFF8E8E93);
        edit.setTextColor(0xFFE6E1E5);
        edit.setTextSize(14);
        edit.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable pill = new GradientDrawable();
        pill.setCornerRadius(dp(22));
        pill.setColor(0xFF262628);
        edit.setBackground(pill);
        edit.setPadding(dp(18), 0, dp(18), 0);
        edit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    submit(edit.getText().toString());
                    return true;
                }
                return false;
            }
        });
        bar.addView(edit, new LinearLayout.LayoutParams(0, dp(44), 1f));

        btnClear = iconButton(Icons.CLOSE);
        btnClear.setVisibility(View.GONE);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText("");
            }
        });
        bar.addView(btnClear, new LinearLayout.LayoutParams(dp(48), dp(48)));

        // ---- Isi: daftar riwayat / saran ----
        FrameLayout body = new FrameLayout(ctx);
        root.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        list = new ListView(ctx);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new ColorDrawable(0x1FFFFFFF));
        list.setCacheColorHint(0);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        body.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        empty = new TextView(ctx);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(32), dp(32), dp(32), dp(32));
        empty.setTextSize(14);
        empty.setTextColor(0xFF8E8E93);
        empty.setVisibility(View.GONE);
        body.addView(empty, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        adapter = new RowAdapter();
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= rows.size()) return;
                Row r = rows.get(position);
                if (r.type == T_CLEAR_ALL) {
                    confirmClearAll();
                } else {
                    submit(r.text);
                }
            }
        });

        // Scroll daftar -> keyboard turun (seperti YouTube)
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    hideKeyboard();
                }
            }

            @Override
            public void onScroll(AbsListView view, int first, int visible, int total) { }
        });

        return root;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle args = getArguments();
        String prefill = args == null ? "" : args.getString(ARG_PREFILL, "");

        edit.setText(prefill);
        if (!prefill.isEmpty()) edit.selectAll();

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                onQueryChanged();
            }
        });
        onQueryChanged();

        edit.requestFocus();
        edit.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (ctx == null) return;
                InputMethodManager imm = (InputMethodManager)
                        ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 150);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        cancelSuggest();
    }

    // ---------- Aksi ----------

    private void submit(String q) {
        q = q == null ? "" : q.trim();
        if (q.isEmpty()) return;
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).submitSearch(q);
        }
    }

    private void confirmClearAll() {
        if (getActivity() == null) return;
        new AlertDialog.Builder(getActivity(), AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setMessage("Hapus semua riwayat pencarian?")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SearchHistory.clear(ctx);
                        rebuildRows();
                    }
                })
                .show();
    }

    private void hideKeyboard() {
        if (ctx == null || edit == null) return;
        InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(edit.getWindowToken(), 0);
    }

    private ImageView iconButton(int type) {
        ImageView v = new ImageView(ctx);
        v.setImageDrawable(Icons.get(ctx, type));
        v.setColorFilter(0xFFE6E1E5);
        int pad = dp(12);
        v.setPadding(pad, pad, pad, pad);
        v.setClickable(true);
        TypedValue tv = new TypedValue();
        if (ctx.getTheme().resolveAttribute(
                android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
            v.setBackgroundResource(tv.resourceId);
        }
        return v;
    }

    // ---------- Daftar riwayat + saran ----------

    private void onQueryChanged() {
        String q = edit.getText().toString().trim();
        btnClear.setVisibility(q.isEmpty() ? View.GONE : View.VISIBLE);
        if (q.isEmpty()) {
            cancelSuggest();
            remoteTitles.clear();
        } else {
            scheduleSuggest(q);
        }
        rebuildRows();
    }

    private void rebuildRows() {
        if (edit == null) return;
        String q = edit.getText().toString().trim();
        ArrayList<String> history = SearchHistory.getAll(ctx);
        rows.clear();

        if (q.isEmpty()) {
            for (String h : history) rows.add(new Row(T_HISTORY, h));
            if (!history.isEmpty()) rows.add(new Row(T_CLEAR_ALL, ""));
            empty.setText("Belum ada riwayat pencarian");
        } else {
            String ql = q.toLowerCase();
            HashSet<String> seen = new HashSet<>();
            int fromHistory = 0;
            for (String h : history) {
                if (fromHistory >= 3) break;
                if (h.toLowerCase().contains(ql) && seen.add(h.toLowerCase())) {
                    rows.add(new Row(T_HISTORY, h));
                    fromHistory++;
                }
            }
            for (String t : remoteTitles) {
                if (rows.size() >= MAX_ROWS) break;
                if (seen.add(t.toLowerCase())) rows.add(new Row(T_SUGGEST, t));
            }
            empty.setText("Belum ada saran.\nTekan Enter untuk mencari \"" + q + "\".");
        }
        adapter.notifyDataSetChanged();
        empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ---------- Saran dari MangaDex (ditunda 350 ms setelah berhenti mengetik) ----------

    private void cancelSuggest() {
        suggestToken++;
        if (pending != null) {
            handler.removeCallbacks(pending);
            pending = null;
        }
    }

    private void scheduleSuggest(final String q) {
        cancelSuggest();
        if (q.length() < 2) {
            remoteTitles.clear();
            return;
        }
        final int token = suggestToken;
        pending = new Runnable() {
            @Override
            public void run() {
                fetchSuggest(q, token);
            }
        };
        handler.postDelayed(pending, 350);
    }

    private void fetchSuggest(final String q, final int token) {
        final FragmentActivity act = getActivity();
        if (act == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = "https://api.mangadex.org/manga"
                            + "?originalLanguage%5B%5D=ko"
                            + "&availableTranslatedLanguage%5B%5D=" + Net.CHAPTER_LANG
                            + "&contentRating%5B%5D=safe"
                            + "&hasAvailableChapters=true"
                            + "&limit=" + MAX_SUGGEST
                            + "&order%5Brelevance%5D=desc"
                            + "&title=" + URLEncoder.encode(q, "UTF-8");
                    JSONObject obj = new JSONObject(Net.get(url));
                    JSONArray data = obj.optJSONArray("data");
                    final ArrayList<String> titles = new ArrayList<>();
                    if (data != null) {
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject attr = data.getJSONObject(i).getJSONObject("attributes");
                            titles.add(FeedFragment.pickTitle(attr));
                        }
                    }
                    act.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (token != suggestToken || !isAdded()) return;
                            remoteTitles.clear();
                            remoteTitles.addAll(titles);
                            rebuildRows();
                        }
                    });
                } catch (Exception ignored) {
                    // Saran gagal dimuat -> cukup diam, riwayat dan tombol Enter tetap jalan
                }
            }
        }).start();
    }

    // ---------- Adapter ----------

    private class RowAdapter extends BaseAdapter {
        @Override
        public int getCount() { return rows.size(); }

        @Override
        public Object getItem(int position) { return rows.get(position); }

        @Override
        public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(16), 0, dp(4), 0);
                row.setMinimumHeight(dp(52));

                h = new Holder();
                h.lead = new ImageView(ctx);
                row.addView(h.lead, new LinearLayout.LayoutParams(dp(24), dp(24)));

                h.label = new TextView(ctx);
                h.label.setTextSize(15);
                h.label.setSingleLine(true);
                h.label.setEllipsize(TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                llp.leftMargin = dp(16);
                row.addView(h.label, llp);

                h.trail = new ImageView(ctx);
                int pad = dp(12);
                h.trail.setPadding(pad, pad, pad, pad);
                h.trail.setFocusable(false);
                row.addView(h.trail, new LinearLayout.LayoutParams(dp(48), dp(48)));

                row.setTag(h);
                convertView = row;
            } else {
                h = (Holder) convertView.getTag();
            }

            final Row r = rows.get(position);
            if (r.type == T_CLEAR_ALL) {
                h.lead.setVisibility(View.INVISIBLE);
                h.trail.setVisibility(View.GONE);
                h.label.setText("Hapus semua riwayat");
                h.label.setTextColor(0xFF8AB4F8);
            } else {
                h.lead.setVisibility(View.VISIBLE);
                h.lead.setImageDrawable(r.type == T_HISTORY ? icHistory : icSearch);
                h.lead.setColorFilter(0xFFA6A6AB);
                h.label.setText(r.text);
                h.label.setTextColor(0xFFE6E1E5);

                h.trail.setVisibility(View.VISIBLE);
                h.trail.setImageDrawable(r.type == T_HISTORY ? icClose : icFill);
                h.trail.setColorFilter(0xFF8E8E93);
                h.trail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (r.type == T_HISTORY) {
                            // X = hapus satu kata kunci dari riwayat
                            SearchHistory.remove(ctx, r.text);
                            rebuildRows();
                        } else {
                            // Panah = isi ke kolom cari tanpa mencari
                            edit.setText(r.text);
                            edit.setSelection(edit.getText().length());
                        }
                    }
                });
            }
            return convertView;
        }
    }
}