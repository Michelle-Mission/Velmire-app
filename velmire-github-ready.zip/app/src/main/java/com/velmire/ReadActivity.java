package com.velmire;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class ReadActivity extends AppCompatActivity {

    private ListView listview_read;
    private final ArrayList<String> imageList = new ArrayList<>();
    private ReadAdapter adapter;
    private TextView headerText;
    private Button btnPrev, btnNext;

    private final HashMap<String, String> mangaData = new HashMap<>();
    private String mangaId;
    private String[] chapterIds;
    private String[] chapterTitles;
    private int index = 0;
    private int startPage = 0;
    private int loadToken = 0;
    private int screenWidth;
    private boolean pageErrorShown = false;

    // ---------- Mode baca nyaman ----------

    private View footerRow;
    private TextView pageIndicator;
    private boolean barsVisible = true;
    private boolean autoNextQueued = false;
    private final Handler autoNextHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.read);

        listview_read = findViewById(R.id.listview_read);
        screenWidth = getResources().getDisplayMetrics().widthPixels;

        Intent in = getIntent();

        mangaId = in.getStringExtra("manga_id");
        chapterIds = in.getStringArrayExtra("chapter_ids");
        chapterTitles = in.getStringArrayExtra("chapter_titles");
        index = in.getIntExtra("index", 0);
        startPage = in.getIntExtra("start_page", 0);

        mangaData.put("id", mangaId == null ? "" : mangaId);

        for (String k : History.META) {
            String v = in.getStringExtra("m_" + k);
            mangaData.put(k, v == null ? "" : v);
        }

        if (chapterIds == null || chapterIds.length == 0) {
            Toast.makeText(
                    this,
                    "Data chapter tidak valid",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        if (index < 0 || index >= chapterIds.length) {
            index = 0;
        }

        listview_read.setDivider(null);
        listview_read.setDividerHeight(0);

        headerText = new TextView(this);
        headerText.setGravity(Gravity.CENTER);
        headerText.setTextColor(0xFFA6A6AB);
        headerText.setTextSize(14);
        headerText.setBackgroundColor(0xFF121212);
        headerText.setPadding(
                Net.dp(this, 16),
                Net.dp(this, 14),
                Net.dp(this, 16),
                Net.dp(this, 14)
        );

        headerText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageList.isEmpty()) {
                    loadChapter(index);
                }
            }
        });

        listview_read.addHeaderView(
                headerText,
                null,
                false
        );

        listview_read.addFooterView(
                buildFooter(),
                null,
                false
        );

        adapter = new ReadAdapter();
        listview_read.setAdapter(adapter);

        setupPageIndicator();
        setupBarToggle();
        applyBarsVisibility();

        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        loadChapter(index);
    }

    @Override
    protected void onPause() {
        super.onPause();

        autoNextHandler.removeCallbacksAndMessages(null);
        saveProgress();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus && !barsVisible) {
            applyBarsVisibility();
        }
    }

    // ---------- Simpan progress ----------

    private void saveProgress() {
        if (chapterIds == null || imageList.isEmpty()) {
            return;
        }

        int page = listview_read.getFirstVisiblePosition()
                - listview_read.getHeaderViewsCount();

        if (page < 0) {
            page = 0;
        }

        if (page >= imageList.size()) {
            page = imageList.size() - 1;
        }

        History.record(
                this,
                mangaData,
                chapterIds[index],
                currentTitle(),
                index,
                page
        );
    }

    // ---------- Navigasi chapter ----------

    private View buildFooter() {
        LinearLayout row = new LinearLayout(this);

        row.setOrientation(LinearLayout.HORIZONTAL);

        row.setPadding(
                Net.dp(this, 12),
                Net.dp(this, 16),
                Net.dp(this, 12),
                Net.dp(this, 32)
        );

        btnPrev = makeButton(
                "< Sebelumnya",
                false
        );

        btnNext = makeButton(
                "Berikutnya >",
                true
        );

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadChapter(index - 1);
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadChapter(index + 1);
            }
        });

        LinearLayout.LayoutParams lp1 =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1f
                );

        lp1.setMargins(
                Net.dp(this, 4),
                0,
                Net.dp(this, 4),
                0
        );

        LinearLayout.LayoutParams lp2 =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1f
                );

        lp2.setMargins(
                Net.dp(this, 4),
                0,
                Net.dp(this, 4),
                0
        );

        row.addView(btnPrev, lp1);
        row.addView(btnNext, lp2);

        footerRow = row;

        return row;
    }

    private Button makeButton(
            String text,
            boolean primary
    ) {
        Button b = new Button(this);

        b.setText(text);
        b.setAllCaps(false);

        b.setTextColor(
                primary
                        ? 0xFFD6E3FF
                        : 0xFFE6E1E5
        );

        b.setTypeface(
                android.graphics.Typeface.create(
                        "sans-serif-medium",
                        android.graphics.Typeface.NORMAL
                )
        );

        GradientDrawable bg = new GradientDrawable();

        bg.setColor(
                primary
                        ? 0xFF2A3A55
                        : 0xFF262628
        );

        bg.setCornerRadius(
                Net.dp(this, 24)
        );

        b.setBackground(bg);

        return b;
    }

    private void updateNavButtons() {
        boolean hasPrev = index > 0;
        boolean hasNext = index < chapterIds.length - 1;

        btnPrev.setEnabled(hasPrev);
        btnPrev.setAlpha(hasPrev ? 1f : 0.35f);

        btnNext.setEnabled(hasNext);
        btnNext.setAlpha(hasNext ? 1f : 0.35f);
    }

    private String currentTitle() {
        if (chapterTitles != null
                && index < chapterTitles.length) {

            return chapterTitles[index];
        }

        return "Chapter";
    }

    // ---------- Load chapter ----------

    private void loadChapter(int newIndex) {
        if (newIndex < 0
                || newIndex >= chapterIds.length) {
            return;
        }

        index = newIndex;

        final int token = ++loadToken;

        pageErrorShown = false;
        autoNextQueued = false;

        autoNextHandler.removeCallbacksAndMessages(null);

        // Halaman awal hanya dipakai untuk
        // chapter pertama yang dibuka dari mode lanjutkan.
        final int resumePage = startPage;
        startPage = 0;

        imageList.clear();

        adapter.notifyDataSetChanged();

        updatePageIndicator();

        listview_read.setSelection(0);

        final String title = currentTitle();

        setTitle(title);

        headerText.setText(
                title + "\nMemuat halaman..."
        );

        updateNavButtons();

        markRead(chapterIds[index]);

        History.record(
                this,
                mangaData,
                chapterIds[index],
                title,
                index,
                resumePage
        );

        final String chapterId = chapterIds[index];

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject obj = new JSONObject(
                            Net.get(
                                    "https://api.mangadex.org/at-home/server/"
                                            + chapterId
                            )
                    );

                    String baseUrl = obj.getString("baseUrl");

                    JSONObject ch =
                            obj.getJSONObject("chapter");

                    String hash =
                            ch.getString("hash");

                    // Mengikuti pengaturan Data Saver aplikasi.
                    boolean dataSaver =
                            Settings.isDataSaver(
                                    ReadActivity.this
                            );

                    JSONArray files =
                            ch.optJSONArray(
                                    dataSaver
                                            ? "dataSaver"
                                            : "data"
                            );

                    if (files == null
                            || files.length() == 0) {

                        throw new Exception(
                                "Chapter ini tidak punya halaman"
                        );
                    }

                    String path =
                            dataSaver
                                    ? "/data-saver/"
                                    : "/data/";

                    final ArrayList<String> urls =
                            new ArrayList<>();

                    for (int i = 0;
                            i < files.length();
                            i++) {

                        urls.add(
                                baseUrl
                                        + path
                                        + hash
                                        + "/"
                                        + files.getString(i)
                        );
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (token != loadToken) {
                                return;
                            }

                            imageList.addAll(urls);

                            adapter.notifyDataSetChanged();

                            updatePageIndicator();

                            headerText.setText(
                                    title
                                            + "\n"
                                            + urls.size()
                                            + " halaman"
                            );

                            if (resumePage > 0
                                    && resumePage < urls.size()) {

                                listview_read.post(
                                        new Runnable() {
                                            @Override
                                            public void run() {
                                                listview_read.setSelection(
                                                        resumePage
                                                                + listview_read
                                                                .getHeaderViewsCount()
                                                );
                                            }
                                        }
                                );
                            }
                        }
                    });

                } catch (final Exception e) {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (token != loadToken) {
                                return;
                            }

                            headerText.setText(
                                    title
                                            + "\nGagal memuat: "
                                            + Net.describe(e)
                                            + "\nTap di sini untuk coba lagi"
                            );
                        }
                    });
                }
            }
        }).start();
    }

    private void markRead(String chapterId) {
        if (mangaId == null) {
            return;
        }

        SharedPreferences prefs =
                getSharedPreferences(
                        "velmire_prefs",
                        MODE_PRIVATE
                );

        Set<String> set =
                new HashSet<String>(
                        prefs.getStringSet(
                                "read_" + mangaId,
                                new HashSet<String>()
                        )
                );

        set.add(chapterId);

        prefs.edit()
                .putStringSet(
                        "read_" + mangaId,
                        set
                )
                .apply();
    }

    // ---------- Mode baca nyaman ----------

    private void setupPageIndicator() {
        pageIndicator = new TextView(this);

        pageIndicator.setTextColor(0xFFE6E1E5);
        pageIndicator.setTextSize(12);

        pageIndicator.setPadding(
                Net.dp(this, 14),
                Net.dp(this, 6),
                Net.dp(this, 14),
                Net.dp(this, 6)
        );

        GradientDrawable bg = new GradientDrawable();

        bg.setColor(0xCC1B1B1D);

        bg.setCornerRadius(
                Net.dp(this, 20)
        );

        pageIndicator.setBackground(bg);

        pageIndicator.setText("0/0");

        FrameLayout.LayoutParams lp =
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        lp.gravity =
                Gravity.BOTTOM
                        | Gravity.CENTER_HORIZONTAL;

        lp.bottomMargin =
                Net.dp(this, 96);

        ViewGroup contentRoot =
                findViewById(android.R.id.content);

        contentRoot.addView(
                pageIndicator,
                lp
        );
    }

    private void updatePageIndicator() {
        if (pageIndicator == null) {
            return;
        }

        if (imageList.isEmpty()) {
            pageIndicator.setText("Memuat...");
            return;
        }

        int firstReal =
                listview_read.getHeaderViewsCount();

        int page =
                listview_read.getFirstVisiblePosition()
                        - firstReal
                        + 1;

        if (page < 1) {
            page = 1;
        }

        if (page > imageList.size()) {
            page = imageList.size();
        }

        pageIndicator.setText(
                page + "/" + imageList.size()
        );
    }

    private void setupBarToggle() {
        listview_read.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        int firstReal =
                                listview_read
                                        .getHeaderViewsCount();

                        int lastReal =
                                firstReal
                                        + imageList.size();

                        // Klik header/footer tidak toggle bar.
                        if (position < firstReal
                                || position >= lastReal) {
                            return;
                        }

                        barsVisible = !barsVisible;

                        applyBarsVisibility();
                    }
                }
        );

        listview_read.setOnScrollListener(
                new AbsListView.OnScrollListener() {

                    @Override
                    public void onScrollStateChanged(
                            AbsListView view,
                            int scrollState) {

                        if (scrollState
                                == SCROLL_STATE_IDLE) {

                            checkAutoNext();
                        }
                    }

                    @Override
                    public void onScroll(
                            AbsListView view,
                            int firstVisibleItem,
                            int visibleItemCount,
                            int totalItemCount) {

                        updatePageIndicator();
                    }
                }
        );
    }

    private void applyBarsVisibility() {
        if (getSupportActionBar() != null) {

            if (barsVisible) {
                getSupportActionBar().show();
            } else {
                getSupportActionBar().hide();
            }
        }

        if (footerRow != null) {
            footerRow.setVisibility(
                    barsVisible
                            ? View.VISIBLE
                            : View.GONE
            );
        }

        View decor =
                getWindow().getDecorView();

        if (barsVisible) {

            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );

        } else {

            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void checkAutoNext() {
        if (autoNextQueued
                || imageList.isEmpty()) {
            return;
        }

        if (index >= chapterIds.length - 1) {
            return;
        }

        int childCount =
                listview_read.getChildCount();

        if (childCount == 0) {
            return;
        }

        int totalRows =
                listview_read.getHeaderViewsCount()
                        + imageList.size();

        int lastVisible =
                listview_read.getLastVisiblePosition();

        View lastChild =
                listview_read.getChildAt(
                        childCount - 1
                );

        boolean footerFullyVisible =
                lastVisible >= totalRows
                        && lastChild.getBottom()
                        <= listview_read.getHeight();

        if (!footerFullyVisible) {
            return;
        }

        autoNextQueued = true;

        Toast.makeText(
                this,
                "Lanjut ke chapter berikutnya...",
                Toast.LENGTH_SHORT
        ).show();

        autoNextHandler.postDelayed(
                new Runnable() {
                    @Override
                    public void run() {
                        autoNextQueued = false;

                        loadChapter(index + 1);
                    }
                },
                900
        );
    }

    // ---------- Halaman ----------

    private void bindPage(
            final ImageView img,
            final String url,
            final int pageNo
    ) {

        img.setMinimumHeight(
                Net.dp(this, 400)
        );

        img.setOnClickListener(null);
        img.setClickable(false);

        Net.loadImage(
                this,
                url,
                img,
                screenWidth,
                true,
                new Net.Callback() {

                    @Override
                    public void onLoaded(
                            Bitmap bitmap
                    ) {

                        img.setMinimumHeight(0);
                    }

                    @Override
                    public void onFailed(
                            String reason
                    ) {

                        img.setMinimumHeight(
                                Net.dp(
                                        ReadActivity.this,
                                        200
                                )
                        );

                        if (!pageErrorShown) {

                            pageErrorShown = true;

                            Toast.makeText(
                                    ReadActivity.this,
                                    "Halaman "
                                            + pageNo
                                            + " gagal: "
                                            + reason
                                            + " (tap gambar untuk ulang)",
                                    Toast.LENGTH_LONG
                            ).show();
                        }

                        img.setOnClickListener(
                                new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        bindPage(
                                                img,
                                                url,
                                                pageNo
                                        );
                                    }
                                }
                        );
                    }
                }
        );
    }

    // ---------- Adapter ----------

    private class ReadAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return imageList.size();
        }

        @Override
        public Object getItem(int position) {
            return imageList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(
                int position,
                View convertView,
                ViewGroup parent
        ) {

            if (convertView == null) {

                convertView =
                        LayoutInflater
                                .from(ReadActivity.this)
                                .inflate(
                                        R.layout.custom_read,
                                        parent,
                                        false
                                );
            }

            ImageView img =
                    convertView.findViewById(
                            R.id.img_page
                    );

            img.setAdjustViewBounds(true);

            img.setScaleType(
                    ImageView.ScaleType.FIT_CENTER
            );

            ViewGroup.LayoutParams lp =
                    img.getLayoutParams();

            if (lp != null) {

                lp.width =
                        ViewGroup.LayoutParams.MATCH_PARENT;

                lp.height =
                        ViewGroup.LayoutParams.WRAP_CONTENT;

                img.setLayoutParams(lp);
            }

            bindPage(
                    img,
                    imageList.get(position),
                    position + 1
            );

            return convertView;
        }
    }
}