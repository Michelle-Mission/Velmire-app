package com.velmire;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Minimal debug activity kept for compatibility with the manifest.
 *
 * The original source archive referenced this activity but did not include it.
 * Replace or remove it when a real debug screen is introduced.
 */
public class DebugActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
