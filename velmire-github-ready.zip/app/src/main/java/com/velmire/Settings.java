package com.velmire;

import android.content.Context;
import android.content.SharedPreferences;

// Pakai file prefs yang sama dengan DetailActivity/ReadActivity ("velmire_prefs")
public class Settings {

    private static final String PREF_NAME = "velmire_prefs";
    private static final String KEY_CHAPTER_LANG = "chapter_lang";
    private static final String KEY_DATA_SAVER = "data_saver";

    public static final String LANG_ALL = "all";

    public static final String[][] LANGUAGES = {
            {LANG_ALL, "Semua Bahasa"},
            {"id", "Indonesia"},
            {"en", "English"},
            {"ja", "Japanese"},
            {"ko", "Korean"},
            {"zh", "Chinese"},
            {"es", "Spanish"},
            {"pt-br", "Portuguese (BR)"}
    };

    public static String getChapterLang(Context ctx) {
        return prefs(ctx).getString(KEY_CHAPTER_LANG, LANG_ALL);
    }

    public static void setChapterLang(Context ctx, String lang) {
        prefs(ctx).edit().putString(KEY_CHAPTER_LANG, lang).apply();
        Net.CHAPTER_LANG = lang; // langsung kepakai tanpa restart app
    }

    public static boolean isDataSaver(Context ctx) {
        return prefs(ctx).getBoolean(KEY_DATA_SAVER, false);
    }

    public static void setDataSaver(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean(KEY_DATA_SAVER, on).apply();
    }

    public static String labelFor(String code) {
        for (String[] l : LANGUAGES) if (l[0].equals(code)) return l[1];
        return code.toUpperCase();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
}