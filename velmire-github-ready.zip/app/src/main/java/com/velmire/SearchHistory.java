package com.velmire;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import java.util.ArrayList;

public class SearchHistory {

    private static final String PREFS = "velmire_prefs";
    private static final String KEY = "search_history";
    private static final int MAX = 20;

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // Terbaru dicari ada di urutan pertama
    public static ArrayList<String> getAll(Context c) {
        ArrayList<String> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                String s = arr.optString(i, "");
                if (!s.isEmpty()) out.add(s);
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static void add(Context c, String q) {
        if (q == null) return;
        q = q.trim();
        if (q.isEmpty()) return;
        ArrayList<String> list = getAll(c);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).equalsIgnoreCase(q)) list.remove(i);
        }
        list.add(0, q);
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(c, list);
    }

    public static void remove(Context c, String q) {
        if (q == null) return;
        ArrayList<String> list = getAll(c);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).equalsIgnoreCase(q)) list.remove(i);
        }
        save(c, list);
    }

    public static void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
    }

    private static void save(Context c, ArrayList<String> list) {
        JSONArray arr = new JSONArray();
        for (String s : list) arr.put(s);
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }
}