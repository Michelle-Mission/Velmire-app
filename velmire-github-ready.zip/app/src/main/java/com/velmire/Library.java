package com.velmire;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

public class Library {

    private static final String PREFS = "velmire_prefs";
    private static final String KEY = "library";
    private static final String[] FIELDS = {
            "id", "title", "coverUrl", "description", "status", "year", "tags"
    };

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // Terbaru ditambahkan ada di urutan pertama
    public static ArrayList<HashMap<String, String>> getAll(Context c) {
        ArrayList<HashMap<String, String>> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                HashMap<String, String> m = new HashMap<>();
                for (String f : FIELDS) m.put(f, o.optString(f, ""));
                out.add(m);
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static boolean contains(Context c, String id) {
        if (id == null) return false;
        for (HashMap<String, String> m : getAll(c)) {
            if (id.equals(m.get("id"))) return true;
        }
        return false;
    }

    public static void add(Context c, HashMap<String, String> manga) {
        String id = manga.get("id");
        if (id == null || id.isEmpty()) return;
        ArrayList<HashMap<String, String>> list = getAll(c);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (id.equals(list.get(i).get("id"))) list.remove(i);
        }
        list.add(0, manga);
        save(c, list);
    }

    public static void remove(Context c, String id) {
        if (id == null) return;
        ArrayList<HashMap<String, String>> list = getAll(c);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (id.equals(list.get(i).get("id"))) list.remove(i);
        }
        save(c, list);
    }

    // return true = sekarang ada di perpustakaan
    public static boolean toggle(Context c, HashMap<String, String> manga) {
        if (contains(c, manga.get("id"))) {
            remove(c, manga.get("id"));
            return false;
        }
        add(c, manga);
        return true;
    }

    private static void save(Context c, ArrayList<HashMap<String, String>> list) {
        JSONArray arr = new JSONArray();
        for (HashMap<String, String> m : list) {
            try {
                JSONObject o = new JSONObject();
                for (String f : FIELDS) o.put(f, m.get(f) == null ? "" : m.get(f));
                arr.put(o);
            } catch (Exception ignored) { }
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }
}