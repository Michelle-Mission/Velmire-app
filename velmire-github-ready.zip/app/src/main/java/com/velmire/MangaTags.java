package com.velmire;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

// Daftar genre disinkronkan langsung dari MangaDex (GET /manga/tag),
// jadi kalau MangaDex nambah/ubah genre, filter di app ikut update tanpa perlu ubah kode.
public class MangaTags {

    public static class Tag {
        public final String id;
        public final String name;

        public Tag(String id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    public interface Callback {
        void onLoaded(ArrayList<Tag> tags);
        void onFailed(String reason);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static ArrayList<Tag> cache;

    public static void get(final Callback cb) {
        if (cache != null) {
            cb.onLoaded(cache);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject obj = new JSONObject(Net.get("https://api.mangadex.org/manga/tag"));
                    JSONArray data = obj.optJSONArray("data");
                    final ArrayList<Tag> list = new ArrayList<>();
                    if (data != null) {
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject t = data.getJSONObject(i);
                            JSONObject attr = t.optJSONObject("attributes");
                            if (attr == null) continue;
                            if (!"genre".equals(attr.optString("group", ""))) continue;
                            JSONObject nameObj = attr.optJSONObject("name");
                            String label = nameObj == null ? "" : nameObj.optString("en", "");
                            if (label.isEmpty()) continue;
                            list.add(new Tag(t.getString("id"), label));
                        }
                        Collections.sort(list, new Comparator<Tag>() {
                            @Override
                            public int compare(Tag a, Tag b) {
                                return a.name.compareToIgnoreCase(b.name);
                            }
                        });
                    }
                    cache = list;
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.onLoaded(list);
                        }
                    });
                } catch (final Exception e) {
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.onFailed(Net.describe(e));
                        }
                    });
                }
            }
        }).start();
    }
}