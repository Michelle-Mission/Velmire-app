package com.velmire;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

// Ikon outline digambar lewat kode (putih, nanti di-tint oleh pemakainya)
public class Icons {

    public static final int HOME = 0;
    public static final int LIBRARY = 1;
    public static final int HISTORY = 2;
    public static final int EXPLORE = 3;
    public static final int SEARCH = 4;
    public static final int BACK = 5;
    public static final int CLOSE = 6;
    public static final int FILL = 7;
    public static final int MORE = 8;

    public static Drawable get(Context c, int type) {
        int size = Net.dp(c, 24);
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        cv.scale(size / 24f, size / 24f);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(0xFFFFFFFF);

        Path path = new Path();

        switch (type) {
            case HOME:
                path.moveTo(3.5f, 11f);
                path.lineTo(12f, 3.5f);
                path.lineTo(20.5f, 11f);
                cv.drawPath(path, p);

                path.reset();
                path.moveTo(5.5f, 9.5f);
                path.lineTo(5.5f, 20f);
                path.lineTo(10f, 20f);
                path.lineTo(10f, 14f);
                path.lineTo(14f, 14f);
                path.lineTo(14f, 20f);
                path.lineTo(18.5f, 20f);
                path.lineTo(18.5f, 9.5f);
                cv.drawPath(path, p);
                break;

            case LIBRARY:
                cv.drawRoundRect(
                    new RectF(3f, 5f, 7f, 20f),
                    1f,
                    1f,
                    p
                );
                cv.drawRoundRect(
                    new RectF(10f, 3f, 14f, 20f),
                    1f,
                    1f,
                    p
                );
                cv.drawRoundRect(
                    new RectF(17f, 7f, 21f, 20f),
                    1f,
                    1f,
                    p
                );
                break;

            case HISTORY:
                cv.drawCircle(12f, 12f, 8.5f, p);

                path.moveTo(12f, 7f);
                path.lineTo(12f, 12f);
                path.lineTo(15.5f, 14f);
                cv.drawPath(path, p);
                break;

            case EXPLORE:
                cv.drawCircle(12f, 12f, 9f, p);

                path.moveTo(15.5f, 8.5f);
                path.lineTo(13.3f, 13.3f);
                path.lineTo(8.5f, 15.5f);
                path.lineTo(10.7f, 10.7f);
                path.close();

                cv.drawPath(path, p);
                break;

            case SEARCH:
                cv.drawCircle(10.5f, 10.5f, 6.5f, p);
                cv.drawLine(15.5f, 15.5f, 20.5f, 20.5f, p);
                break;

            case BACK:
                path.moveTo(19.5f, 12f);
                path.lineTo(4.5f, 12f);
                cv.drawPath(path, p);

                path.reset();
                path.moveTo(11f, 5f);
                path.lineTo(4.5f, 12f);
                path.lineTo(11f, 19f);
                cv.drawPath(path, p);
                break;

            case CLOSE:
                cv.drawLine(6f, 6f, 18f, 18f, p);
                cv.drawLine(18f, 6f, 6f, 18f, p);
                break;

            case FILL:
                cv.drawLine(17f, 17f, 7.5f, 7.5f, p);

                path.moveTo(7.5f, 15f);
                path.lineTo(7.5f, 7.5f);
                path.lineTo(15f, 7.5f);
                cv.drawPath(path, p);
                break;
                
            case MORE:
    Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    dot.setStyle(Paint.Style.FILL);
    dot.setColor(0xFFFFFFFF);
    cv.drawCircle(6.5f, 12f, 1.8f, dot);
    cv.drawCircle(12f, 12f, 1.8f, dot);
    cv.drawCircle(17.5f, 12f, 1.8f, dot);
    break;    
    
        }

        return new BitmapDrawable(c.getResources(), bmp);
    }
}