package com.velmire;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class MoreFragment extends Fragment {

    private Context ctx;
    private TextView rowLangSubtitle;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ctx = inflater.getContext();

        LinearLayout page = new LinearLayout(ctx);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFF121212); // FIX: samakan dengan background layar lain (sebelumnya 0xFF000000)

        // ---- Bar judul, disamakan dengan gaya bar di tab lain ----
        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Net.dp(ctx, 16), 0, Net.dp(ctx, 16), 0);
        page.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Net.dp(ctx, 64)));

        TextView title = new TextView(ctx);
        title.setText("Lainnya");
        title.setTextColor(0xFFE6E1E5);
        title.setTextSize(22);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        bar.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ScrollView scroll = new ScrollView(ctx);
        scroll.setBackgroundColor(0xFF121212);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, Net.dp(ctx, 4), 0, Net.dp(ctx, 24));

        // ---- Bahasa chapter ----
        rowLangSubtitle = new TextView(ctx);
        root.addView(buildRow("Bahasa chapter", rowLangSubtitle,
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) { showLangDialog(); }
                }));
        updateLangSubtitle();

        root.addView(divider());

        // ---- Mode hemat data ----
        final Switch dataSaverSwitch = new Switch(ctx);
        dataSaverSwitch.setChecked(Settings.isDataSaver(ctx));
        View rowDataSaver = buildRowWithSwitch("Mode hemat data",
                "Muat gambar chapter kualitas lebih rendah, lebih hemat kuota",
                dataSaverSwitch);
        dataSaverSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Settings.setDataSaver(ctx, isChecked);
            }
        });
        root.addView(rowDataSaver);

        root.addView(divider());

        // ---- Hapus cache ----
        TextView hapusSubtitle = new TextView(ctx);
        hapusSubtitle.setText("Bersihkan cover manga yang tersimpan di perangkat");
        root.addView(buildRow("Hapus cache", hapusSubtitle,
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) { confirmClearCache(); }
                }));

        scroll.addView(root);
        page.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        return page;
    }

    // Garis pemisah tipis, dipakai biar konsisten dengan gaya minimalis tab lain
    private View divider() {
        View v = new View(ctx);
        v.setBackgroundColor(0x14FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Net.dp(ctx, 1));
        lp.leftMargin = Net.dp(ctx, 16);
        return v;
    }

    private void showLangDialog() {
        if (ctx == null) return;
        String current = Net.CHAPTER_LANG;
        String[] labels = new String[Settings.LANGUAGES.length];
        int checkedIdx = 0;
        for (int i = 0; i < Settings.LANGUAGES.length; i++) {
            labels[i] = Settings.LANGUAGES[i][1];
            if (Settings.LANGUAGES[i][0].equals(current)) checkedIdx = i;
        }
        new AlertDialog.Builder(ctx, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Bahasa chapter")
                .setSingleChoiceItems(labels, checkedIdx, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Settings.setChapterLang(ctx, Settings.LANGUAGES[which][0]);
                        updateLangSubtitle();
                        dialog.dismiss();

                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).refreshFeeds();
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void updateLangSubtitle() {
        if (rowLangSubtitle == null) return;
        rowLangSubtitle.setText("Manga tanpa chapter bahasa ini disembunyikan  •  "
                + Settings.labelFor(Net.CHAPTER_LANG));
    }

    private void confirmClearCache() {
        if (ctx == null) return;
        new AlertDialog.Builder(ctx, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Hapus cache")
                .setMessage("Cover yang sudah diunduh akan dihapus dan diunduh ulang saat dibutuhkan. Lanjutkan?")
                .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Net.clearCache(ctx);
                        Toast.makeText(ctx, "Cache dihapus", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // Efek ripple pas baris ditekan, biar konsisten dengan interaksi di tab lain
    private void applyRipple(View v) {
        TypedValue tv = new TypedValue();
        if (ctx.getTheme().resolveAttribute(
                android.R.attr.selectableItemBackground, tv, true)) {
            v.setBackgroundResource(tv.resourceId);
        }
    }

    private View buildRow(String title, TextView subtitleView, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(Net.dp(ctx, 16), Net.dp(ctx, 14), Net.dp(ctx, 16), Net.dp(ctx, 14));
        row.setClickable(true);
        row.setFocusable(true);
        applyRipple(row);
        row.setOnClickListener(click);

        TextView t = new TextView(ctx);
        t.setText(title);
        t.setTextColor(0xFFE6E1E5);
        t.setTextSize(16);
        row.addView(t);

        subtitleView.setTextColor(0xFF8E8E93);
        subtitleView.setTextSize(13);
        subtitleView.setPadding(0, Net.dp(ctx, 4), 0, 0);
        row.addView(subtitleView);

        return row;
    }

    private View buildRowWithSwitch(String title, String subtitle, Switch sw) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Net.dp(ctx, 16), Net.dp(ctx, 14), Net.dp(ctx, 16), Net.dp(ctx, 14));

        LinearLayout texts = new LinearLayout(ctx);
        texts.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textsLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        TextView t = new TextView(ctx);
        t.setText(title);
        t.setTextColor(0xFFE6E1E5);
        t.setTextSize(16);
        texts.addView(t);

        TextView sub = new TextView(ctx);
        sub.setText(subtitle);
        sub.setTextColor(0xFF8E8E93);
        sub.setTextSize(13);
        sub.setPadding(0, Net.dp(ctx, 4), 0, 0);
        texts.addView(sub);

        row.addView(texts, textsLp);
        row.addView(sw);
        return row;
    }
}