# Velmire Development Roadmap

## Build & project setup

- [ ] Add Gradle Wrapper.
- [ ] Verify clean build from a fresh checkout.
- [ ] Add GitHub Actions build verification.
- [ ] Decide and add an open-source license.

## Architecture

- [ ] Introduce a dedicated MangaDex API client.
- [ ] Move API URLs/configuration out of UI classes.
- [ ] Introduce repository/state separation.
- [ ] Consider Room for structured local data.

## Reader

- [ ] Improve reader error/retry UX.
- [ ] Review cache eviction and disk limits.
- [ ] Test chapter auto-next on edge cases.
- [ ] Improve progress persistence around fast scrolling and app termination.

## Search & browsing

- [ ] Add automated tests for filtering.
- [ ] Review pagination and API rate-limit behavior.
- [ ] Improve empty/error states.
- [ ] Add loading-state tests.

## Quality

- [ ] Add unit tests for `History`, `Library`, and `Settings`.
- [ ] Add tests for API response parsing.
- [ ] Add UI tests for critical reader flows.
- [ ] Add lint/static analysis to CI.

## Release

- [ ] Configure release signing outside the repository.
- [ ] Review permissions and network security.
- [ ] Review privacy policy requirements.
- [ ] Verify MangaDex API/content usage requirements.
- [ ] Test supported Android versions and screen sizes.
