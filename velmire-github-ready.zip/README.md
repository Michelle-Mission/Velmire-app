# Velmire

Velmire is an Android manga/manhwa reader project written in Java. The current implementation uses the MangaDex API for manga metadata, chapter data, and reader images.

> **Project status:** early development. The repository has been prepared from the supplied source archive, including minimal compatibility classes for manifest references. A Gradle Wrapper and automated build verification still need to be added.

## Features

The current source contains implementations for:

- Home/feed manga browsing
- Manga search with local search history and remote suggestions
- Manga detail pages
- Chapter listing and language filtering
- MangaDex genre/tag filtering
- Sorting by popularity, latest update, and rating
- Status filtering
- Reading chapters as a vertical image reader
- Automatic next-chapter navigation
- Reading progress/history
- Local library/favorites
- Data Saver setting
- Chapter language preference
- Local image memory/disk caching
- Dark Material 3 UI

## Tech stack

| Component | Current setup |
|---|---|
| Language | Java |
| Platform | Android |
| Package | `com.velmire` |
| Compile SDK | 34 |
| Target SDK | 34 |
| Minimum SDK | 21 |
| Android Gradle Plugin | 8.12.0 |
| UI | AndroidX AppCompat + Material Components |
| Data source | MangaDex API |
| Local persistence | SharedPreferences |
| Build system | Gradle |

## Project structure

```text
.
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/velmire/
│       │   ├── MainActivity.java
│       │   ├── FeedFragment.java
│       │   ├── SearchFragment.java
│       │   ├── LibraryFragment.java
│       │   ├── HistoryFragment.java
│       │   ├── MoreFragment.java
│       │   ├── DetailActivity.java
│       │   ├── ReadActivity.java
│       │   ├── Net.java
│       │   ├── MangaAdapter.java
│       │   ├── MangaTags.java
│       │   ├── Library.java
│       │   ├── History.java
│       │   ├── SearchHistory.java
│       │   └── Settings.java
│       └── res/
├── docs/
├── .github/
├── build.gradle
├── settings.gradle
├── gradle.properties
└── README.md
```

## Getting started

### Requirements

Use:

- Android Studio with Android SDK 34 installed
- JDK 17
- Gradle compatible with Android Gradle Plugin 8.12.x

The repository currently does not include the Gradle Wrapper. For reproducible GitHub/CI builds, add the wrapper before setting up CI.

### Open the project

1. Clone the repository.
2. Open the repository root in Android Studio.
3. Install Android SDK 34 when Android Studio asks for it.
4. Ensure the project uses JDK 17.
5. Sync Gradle.
6. Resolve the missing source classes described below.
7. Build and run on an Android 5.0+ device/emulator.

## Known issues / blockers

The supplied archive was missing two classes referenced by `AndroidManifest.xml`:

- `com.velmire.SketchApplication`
- `com.velmire.DebugActivity`

This GitHub-ready package includes minimal compatibility implementations for both. They are intentionally small and can be replaced with the project's real application/debug implementations later.

Other items to review before a production release:

- Add a Gradle Wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/*`).
- Decide and add an open-source license.
- Add automated tests.
- Add CI after the Gradle Wrapper is available.
- Review `android:usesCleartextTraffic="true"` and remove it if the app does not intentionally require HTTP.
- Move API/base URLs into a central configuration class if more endpoints are added.
- Review MangaDex API usage, attribution, rate limits, and current terms before publishing.
- Review release signing and secure handling of keystores.
- Review image cache size and storage behavior on low-storage devices.

See [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md) for development notes and [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the current architecture.

## Data and privacy

The current source stores library/favorites, reading history, settings, and search history locally using Android `SharedPreferences`.

The app requests:

- `INTERNET`
- `ACCESS_NETWORK_STATE`

Manga metadata, chapter information, and reader images are fetched from MangaDex infrastructure.

The repository should not contain:

- API keys
- signing keys
- `google-services.json` unless intentionally required and safe to publish
- local machine configuration
- generated APK/AAB files
- IDE metadata

## MangaDex

Velmire currently consumes public MangaDex endpoints. MangaDex is an external service and is not represented as part of this project.

Before distributing Velmire, verify that the application's use of MangaDex APIs, covers, and chapter images complies with the service's current policies and the rights applicable to the content being displayed.

## Contributing

Pull requests are welcome once the project is buildable from a clean checkout.

Please read [`CONTRIBUTING.md`](CONTRIBUTING.md) before making changes.

## License

**License: TBD.**

Do not assume that this repository grants permission to redistribute or commercially use the code until a license is added by the project owner.
