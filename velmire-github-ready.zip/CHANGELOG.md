# Changelog

All notable changes to Velmire should be documented here.

## Unreleased

### Added

- Initial GitHub project documentation
- Development and contribution guidelines
- Architecture and API notes
- GitHub issue and pull-request templates

### Known

- Minimal compatibility implementations for the missing `SketchApplication` and `DebugActivity` manifest references were added.
- Gradle Wrapper is not included yet.
- Project license has not been selected yet.
