# Security Policy

## Supported versions

Velmire is currently under active development. Security fixes should target the latest development branch unless the project owner states otherwise.

## Reporting a vulnerability

Please do **not** publish sensitive vulnerability details in a public issue.

Until a dedicated private security contact is configured, contact the project maintainer privately through the repository owner's preferred contact method.

Include:

- Affected version/commit
- Android version and device/emulator
- Reproduction steps
- Expected behavior
- Actual behavior
- Impact
- Proof of concept, if safe to provide

Do not include passwords, private tokens, signing keys, or other secrets in a report.

## Secrets

Never commit:

- Android signing keystores
- Keystore passwords
- API credentials
- Private tokens
- Local `.env` files
- Personal access tokens
