# Contributing to Velmire

Thanks for helping develop Velmire.

## Before you start

The current repository is an early development snapshot. Check [`README.md`](README.md) for known build blockers before opening a pull request.

## Development workflow

1. Create a branch from the default branch.
2. Keep each change focused on one problem or feature.
3. Avoid committing generated files.
4. Test the affected screen or flow on an emulator/device.
5. Update documentation when behavior, setup, or architecture changes.
6. Open a pull request with a clear description.

Suggested branch names:

```text
feature/search-filters
fix/reader-progress
refactor/network-layer
docs/setup
```

## Code guidelines

The existing project is Java-based. When adding code:

- Follow the surrounding style unless there is a good reason to improve it.
- Keep Android UI work on the main thread.
- Keep network and expensive image work off the main thread.
- Reuse existing helpers where practical.
- Avoid adding a dependency for functionality that can reasonably be implemented with the current stack.
- Validate null/empty API fields because remote metadata can change.
- Do not log private user data or credentials.
- Do not commit API keys, signing keys, or local configuration.

## API changes

Velmire currently communicates with MangaDex directly.

When changing API behavior:

- Document the endpoint and expected response shape.
- Handle HTTP errors and rate limiting.
- Avoid unnecessary repeated requests.
- Preserve cancellation/stale-request protection where applicable.
- Test empty, partial, and malformed API responses.

## Pull requests

A good PR should explain:

- What changed
- Why it changed
- How it was tested
- Any known limitations
- Screenshots for meaningful UI changes

Keep unrelated formatting changes out of feature/fix PRs when possible.

## Commit messages

Use concise, descriptive commits. Examples:

```text
feat: add chapter language filter
fix: restore reader progress
refactor: simplify image cache
docs: document local development
```
