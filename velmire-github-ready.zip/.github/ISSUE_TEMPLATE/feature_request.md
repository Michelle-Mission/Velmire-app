---
name: Feature request
about: Suggest an improvement
title: "[Feature] "
labels: enhancement
---

## Problem

What problem would this feature solve?

## Proposed solution

Describe the desired behavior.

## Alternatives

What other approaches did you consider?

## Additional context

Screenshots, mockups, or examples are welcome.
