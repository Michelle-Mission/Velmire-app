---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

## Description

What happened?

## Steps to reproduce

1.
2.
3.

## Expected behavior

What should have happened?

## Actual behavior

What happened instead?

## Environment

- Android version:
- Device/emulator:
- Velmire version/commit:

## Logs / screenshots

Remove personal data, tokens, and other secrets before posting.
