## What changed?

Describe the change.

## Why?

Explain the problem or use case.

## How was it tested?

- [ ] Android Studio build
- [ ] Emulator/device test
- [ ] Relevant screen tested
- [ ] Error/empty state tested

## Screenshots

Add screenshots or write `N/A` if not applicable.

## Checklist

- [ ] No secrets or signing files added
- [ ] Documentation updated if needed
- [ ] No unrelated changes included
- [ ] Existing behavior was checked for regressions
